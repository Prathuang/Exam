﻿using Bank.Lib.ConfigurationXML;
using Bank.Lib.Data;
using Bank.Lib.UIBusiness;
using System;
using System.IO;
using System.Windows.Forms;

namespace BankUI
{
    public partial class frmMain : Form
    {
        private UserProfile UserProfile = new UserProfile();
        private string ApiConfigUri = string.Empty;

        private ApiConfiguration ApiConfiguration = new ApiConfiguration();
        private AllMaster AllMaster = new AllMaster();

        public frmMain()
        {
            InitializeComponent();
        }

        public frmMain(UserProfile userProfile, ApiConfiguration apiConfiguration)
        {
            InitializeComponent();
            UserProfile = userProfile;
            if (apiConfiguration == null)
            {
                if (string.IsNullOrEmpty(ApiConfigUri))
                {
                    ApiConfigUri = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"App_Data\ApiConfig.xml");
                }
                ApiConfiguration = new ApiConfiguration(ApiConfigUri);
            }
            else
            {
                ApiConfiguration = apiConfiguration;
            }
            try
            {
                bool isSuccess = false;
                string errorMessage = string.Empty;
                CallAPIBusiness bs = new CallAPIBusiness(UserProfile, ApiConfiguration, InterfaceServiceName.GetAllMaster);
                AllMaster = bs.CallExternalAPI<AllMaster, ManageUser>(null, ref isSuccess, ref errorMessage);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void toolStripManageCustomer_Click(object sender, EventArgs e)
        {
            UserControl Sender = null;
            Bank.UC.ucManageCustomer.ucManageCustomer uc = new Bank.UC.ucManageCustomer.ucManageCustomer(UserProfile, ApiConfiguration, AllMaster);
            Sender = uc;
            InitUserControl(Sender);
        }

        private void toolStripFinancialBusiness_Click(object sender, EventArgs e)
        {
            UserControl Sender = null;
            Bank.UC.ucFinancialBusiness.ucFinancialBusiness uc = new Bank.UC.ucFinancialBusiness.ucFinancialBusiness(UserProfile, ApiConfiguration, AllMaster);
            Sender = uc;
            InitUserControl(Sender);
        }

        private void InitUserControl(object sender)
        {
            try
            {
                if (sender != null)
                {
                    UserControl uc = (UserControl)sender;

                    uc.Location = new System.Drawing.Point(0, 24);
                    uc.TabIndex = 1;

                    uc.Disposed += new EventHandler(uc_Disposed);
                    this.Controls.Add(uc);
                    menuStrip1.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        void uc_Disposed(object sender, EventArgs e)
        {
            UserControl uc = (UserControl)sender;
            this.Controls.Remove(uc);
            menuStrip1.Enabled = true;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}