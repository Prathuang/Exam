﻿using Bank.Lib.ConfigurationXML;
using Bank.Lib.Data;
using Bank.Lib.UIBusiness;
using System;
using System.IO;
using System.Windows.Forms;

namespace BankUI
{
    public partial class frmLogin : Form
    {
        public UserProfile UserProfile = new UserProfile();
        private string ApiConfigUri = string.Empty;

        public ApiConfiguration ApiConfiguration { get; set; }

        public frmLogin()
        {
            InitializeComponent();

            string ApiConfigUri = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"App_Data\ApiConfig.xml");
            ApiConfiguration = new ApiConfiguration(ApiConfigUri);

            string HostIp = DoBusiness.GetHostIp;
            UserProfile.ProgramName = "BankUI";
            UserProfile.Guid = System.Guid.NewGuid().ToString();
            UserProfile.ClientIp = HostIp;
            UserProfile.HostIp = HostIp;
            UserProfile.MessageLog = DoBusiness.GetMessageLog;// "{0}|{1}|{2}|{3}| {4}";
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            bool isSuccess = false;
            string errorMessage = string.Empty;
            try
            {
                this.Cursor = Cursors.WaitCursor;
                if (string.IsNullOrEmpty(txtUserName.Text))
                {
                    MessageBox.Show("Please input User Name", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtUserName.Focus();
                }
                else if (string.IsNullOrEmpty(txtPassword.Text))
                {
                    MessageBox.Show("Please input Password", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtPassword.Focus();
                }
                else
                {
                    ManageUser request = new ManageUser();

                    request.UserName = txtUserName.Text;
                    request.Password = Bank.Lib.DataSecurity.EncryptDecrypt_MD5.GetEncrypt(txtPassword.Text);

                    CallAPIBusiness bs = new CallAPIBusiness(UserProfile, ApiConfiguration, InterfaceServiceName.CheckUserLogin);
                    ManageUserList response = bs.CallExternalAPI<ManageUserList, ManageUser>(request, ref isSuccess, ref errorMessage);
                    if (!isSuccess)
                    {
                        txtPassword.Clear();
                        MessageBox.Show(errorMessage, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        if (response.MessageCode.ToUpper().Equals("SUCCESS"))
                        {
                            ManageUser manageUser = new ManageUser();
                            manageUser.UserName = txtUserName.Text;
                            manageUser.RoleCode = response.ObjectList[0].RoleCode;
                            manageUser.FirstNameTH = response.ObjectList[0].FirstNameTH;
                            manageUser.MiddleNameTH = response.ObjectList[0].MiddleNameTH;
                            manageUser.LastNameTH = response.ObjectList[0].LastNameTH;
                            manageUser.FirstNameEN = response.ObjectList[0].FirstNameEN;
                            manageUser.MiddleNameEN = response.ObjectList[0].MiddleNameEN;
                            manageUser.LastNameEN = response.ObjectList[0].LastNameEN;
                            manageUser.BranchCode = response.ObjectList[0].BranchCode;

                            UserProfile.ManageUser = manageUser;
                            DialogResult = DialogResult.Yes;
                        }
                        else
                        {
                            txtPassword.Clear();
                            MessageBox.Show(response.MessageDesc, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            txtUserName.Focus();
        }

        private void txtPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == 13)
            {
                btnLogin_Click(sender, e);
            }
        }

        private void txtUserName_Enter(object sender, EventArgs e)
        {
            Application.CurrentInputLanguage = InputLanguage.FromCulture(new System.Globalization.CultureInfo("en-US"));
        }

        private void txtPassword_Enter(object sender, EventArgs e)
        {
            Application.CurrentInputLanguage = InputLanguage.FromCulture(new System.Globalization.CultureInfo("en-US"));
        }
    }
}