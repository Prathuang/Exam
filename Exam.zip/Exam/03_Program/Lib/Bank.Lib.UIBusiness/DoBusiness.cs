﻿using System;
using System.IO;

namespace Bank.Lib.UIBusiness
{
    public class DoBusiness
    {
        public static string GetHostIp
        {
            get
            {
                try
                {
                    string hostname = System.Net.Dns.GetHostName();
                    string hostip = "";
                    System.Net.IPAddress[] ip_addr = System.Net.Dns.GetHostEntry(hostname).AddressList;

                    for (int i = 0; i < ip_addr.Length; i++)
                    {
                        if (ip_addr[i].AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                        {
                            hostip = ip_addr[i].ToString();
                            break;
                        }
                    }
                    return hostip;
                }
                catch
                {
                    return "";
                }
            }
        }

        public static string GetMessageLog
        {
            get
            {
                return "{0}|{1}|{2}|{3}| {4}";//"Guid:{0}|ClientIp:{1}|HostIp:{2}|MethodName:{3}| Message:{4}"
            }
        }

        public static string ConvertImageToBase64String(System.Drawing.Image image)
        {
            string base64String = string.Empty;

            using (MemoryStream m = new MemoryStream())
            {
                image.Save(m, image.RawFormat);
                byte[] imageBytes = m.ToArray();
                base64String = Convert.ToBase64String(imageBytes);
            }

            return base64String;
        }

        public static bool CheckEMail(string EMail)
        {
            bool result = false;
            try
            {
                new System.Net.Mail.MailAddress(EMail);
                result = true;
            }
            catch (ArgumentException ex)
            {
                result = false;
            }
            catch (FormatException ex)
            {
                result = false;
            }
            return result;
        }

        public static bool CheckIsNumber(string strIn)
        {
            bool result = false;
            try
            {
                decimal.Parse(strIn);
                result = true;
            }
            catch
            {
                result = false;
            }
            return result;
        }

        public static bool CheckMoneyForSave(string strBalance, string strAvailable)
        {
            bool result = false;
            decimal Balance = Convert.ToDecimal(strBalance);
            decimal Available = Convert.ToDecimal(strAvailable);
            if (Balance >= Available)
            {
                result = true;
            }
            return result;
        }
    }
}
