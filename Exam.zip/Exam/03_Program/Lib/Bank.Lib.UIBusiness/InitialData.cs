﻿using Bank.Lib.ConfigurationXML;

namespace Bank.Lib.UIBusiness
{
    public class InitialData
    {
        public ApiConfiguration ApiConfiguration = new ApiConfiguration();

        public string MessageCode = string.Empty;
        public string MessageDesc = string.Empty;

        public string MessageLog = string.Empty; // = "{0}|{1}|{2}|{3}| {4}";//"Guid:{0}|ClientIp:{1}|HostIp:{2}|MethodName:{3}| Message:{4}"

        public string Guid = string.Empty;
        public string ClientIp = string.Empty;
        public string HostIp = string.Empty;

        public string MethodName = string.Empty;
        public string ProgramName = string.Empty;

        public string ApiUrl = string.Empty;
        public int Timeout = 0;
        public string MethodApiName = string.Empty;
    }
}