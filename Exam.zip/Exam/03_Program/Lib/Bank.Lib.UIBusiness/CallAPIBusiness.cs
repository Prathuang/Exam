﻿using Bank.Lib.ConfigurationXML;
using Bank.Lib.Data;
using System;

namespace Bank.Lib.UIBusiness
{
    public class CallAPIBusiness : InitialData
    {
        public CallAPIBusiness(UserProfile userProfile, ApiConfiguration apiConfiguration, InterfaceServiceName serviceName)
        {
            try
            {
                ApiConfiguration = apiConfiguration;
                MessageLog = userProfile.MessageLog;
                ProgramName = userProfile.ProgramName;

                ClientIp = userProfile.ClientIp;
                HostIp = userProfile.HostIp;
                Guid = userProfile.Guid;

                MethodApiName = serviceName.ToString();
                ApiUrl = ApiConfiguration.ApiConfig.Service[MethodApiName].Url;
                Timeout = ApiConfiguration.ApiConfig.Service[MethodApiName].Timeout;

                System.Configuration.ConfigurationManager.RefreshSection("appSettings");

                InitialWriteLogFile.Initial(ProgramName);
            }
            catch { }
        }

        public DataTypeResponse CallExternalAPI<DataTypeResponse, DataTypeRequest>(DataTypeRequest request, ref bool isSuccess, ref string errorMessage)
        {
            MethodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            isSuccess = false;
            DateTime StartTime = DateTime.Now;
            DataTypeResponse response = default(DataTypeResponse);
            response = Activator.CreateInstance<DataTypeResponse>();
            try
            {
                log4net.LogManager.GetLogger(ProgramName).InfoFormat(MessageLog, Guid, ClientIp, HostIp, MethodName, string.Format("Start CallExternalAPI (Method API Name : {0})", MethodApiName));
                Bank.Lib.CallRestfulAPI.CallRestfulAPI process = new Bank.Lib.CallRestfulAPI.CallRestfulAPI(ApiUrl, Timeout);
                response = process.CallAPI<DataTypeResponse, DataTypeRequest>(request, ref isSuccess, ref errorMessage);
            }
            catch (Exception ex)
            {
                isSuccess = false;
                errorMessage = ex.Message;
                log4net.LogManager.GetLogger(ProgramName).ErrorFormat(MessageLog, Guid, ClientIp, HostIp, MethodName, string.Format("Error CallExternalAPI (Method API Name : {0}) : {1}", MethodApiName, ex.Message));
            }
            finally
            {
                log4net.LogManager.GetLogger(ProgramName).InfoFormat(MessageLog, Guid, ClientIp, HostIp, MethodName, string.Format("End CallExternalAPI (Method API Name : {0}) => Process : {1} ms.", MethodApiName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }
            return response;
        }
    }
}