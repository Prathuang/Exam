﻿using System.Collections.Generic;

namespace Bank.Lib.Data
{
    public class SubDistrictList : ResultResponse
    {
        private List<SubDistrict> _objectList = new List<SubDistrict>();

        public List<SubDistrict> ObjectList
        {
            get
            {
                return _objectList;
            }

            set
            {
                _objectList = value;
            }
        }
    }
}