﻿using System.Collections.Generic;

namespace Bank.Lib.Data
{
    public class TypeFinancialList : ResultResponse
    {
        private List<TypeFinancial> _objectList = new List<TypeFinancial>();

        public List<TypeFinancial> ObjectList
        {
            get
            {
                return _objectList;
            }

            set
            {
                _objectList = value;
            }
        }
    }
}