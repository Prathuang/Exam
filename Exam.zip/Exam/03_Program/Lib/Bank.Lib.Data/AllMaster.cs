﻿using System.Collections.Generic;

namespace Bank.Lib.Data
{
    public class AllMaster : ResultResponse
    {
        public List<Banks> AllBanks { get; set; }

        public List<Branch> AllBranch { get; set; }

        public List<Channel> AllChannel { get; set; }

        public List<SubDistrict> AllSubDistrict { get; set; }

        public List<District> AllDistrict { get; set; }

        public List<Province> AllProvince { get; set; }

        public List<Occupation> AllOccupation { get; set; }

        public List<Title> AllTitle { get; set; }

        public List<TypeFinancial> AllTypeFinancial { get; set; }
    }
}