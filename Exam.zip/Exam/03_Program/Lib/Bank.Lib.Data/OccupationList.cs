﻿using System.Collections.Generic;

namespace Bank.Lib.Data
{
    public class OccupationList : ResultResponse
    {
        private List<Occupation> _objectList = new List<Occupation>();

        public List<Occupation> ObjectList
        {
            get
            {
                return _objectList;
            }

            set
            {
                _objectList = value;
            }
        }
    }
}