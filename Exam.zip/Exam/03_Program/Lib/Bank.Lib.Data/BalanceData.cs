﻿namespace Bank.Lib.Data
{
    public class BalanceData
    {
        public string AccountNo { get; set; }
        public decimal Balance { get; set; }
    }
}