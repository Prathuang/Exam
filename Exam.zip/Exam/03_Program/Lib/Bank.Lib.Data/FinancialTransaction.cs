﻿using System;

namespace Bank.Lib.Data
{
    public class FinancialTransaction
    {
        public int Id { get; set; }
        public string TypeFinancialCode { get; set; }
        public string ChannelCode { get; set; }
        public string BranchCode { get; set; }
        public string AccountNo { get; set; }

        public string TypeCash { get; set; }
        public decimal BeforeBalance { get; set; }
        public decimal FeeAmount { get; set; }
        public decimal Amount { get; set; }
        public decimal Balance { get; set; }

        public string RelatedBankCode { get; set; }
        public string RelatedAccountNo { get; set; }
        public string Description { get; set; }
        //public DateTime TransactionDate { get; set; }
        public string TransactionBy { get; set; }
        public string MemoMessage { get; set; }
        public string IsSameBank { get; set; }
    }
}