﻿namespace Bank.Lib.Data
{
    public class Customer : CreateAndModifiedData
    {
        //public int Id { get; set; }
        public string AccountNo { get; set; }
        public string TitleCode { get; set; }
        public string FirstNameTH { get; set; }
        public string MiddleNameTH { get; set; }
        public string LastNameTH { get; set; }

        //public string TitleEN { get; set; }
        public string FirstNameEN { get; set; }
        public string MiddleNameEN { get; set; }
        public string LastNameEN { get; set; }

        public string CitizenId { get; set; }
        public string DateOfBirth { get; set; }
        public string MobileNo { get; set; }
        public string EMail { get; set; }
        public string Address { get; set; }

        public string Soi { get; set; }
        public string Road { get; set; }
        public string SubdistrictCode { get; set; }
        public string DistrictCode { get; set; }
        public string ProvinceCode { get; set; }

        public string ZipCode { get; set; }
        public string BranchCode { get; set; }
        public string OccupationCode { get; set; }
        public string IsSendCitizenCard { get; set; }
        public string IsSendImage { get; set; }
        public string FullNameTH { get; set; }
        public string FullNameEN { get; set; }
        public decimal Balance { get; set; }

        public string ImageBase64 { get; set; }
        public string ImageExtension { get; set; }
        public string CitizenIdCardImageBase64 { get; set; }
        public string CitizenIdCardImageExtension { get; set; }
        public string TitleNameTH { get; set; }
        public string TitleShortNameTH { get; set; }
        public string TitleNameEN { get; set; }
        public string TitleShortNameEN { get; set; }
    }
}