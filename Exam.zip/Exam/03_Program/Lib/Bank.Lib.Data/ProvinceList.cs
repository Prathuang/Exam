﻿using System.Collections.Generic;

namespace Bank.Lib.Data
{
    public class ProvinceList : ResultResponse
    {
        private List<Province> _objectList = new List<Province>();

        public List<Province> ObjectList
        {
            get
            {
                return _objectList;
            }

            set
            {
                _objectList = value;
            }
        }
    }
}