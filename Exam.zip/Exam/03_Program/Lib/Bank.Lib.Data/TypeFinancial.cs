﻿namespace Bank.Lib.Data
{
    public class TypeFinancial : CreateAndModifiedData
    {
        public string TypeFinancialCode { get; set; }
        public string TypeFinancialNameTH { get; set; }
        public string TypeFinancialNameEN { get; set; }
    }
}