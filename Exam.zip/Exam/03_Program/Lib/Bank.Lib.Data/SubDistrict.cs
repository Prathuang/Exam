﻿namespace Bank.Lib.Data
{
    public class SubDistrict : CreateAndModifiedData
    {
        public string ProvinceCode { get; set; }
        public string DistrictCode { get; set; }
        public string SubDistrictCode { get; set; }
        public string SubDistrictNameTH { get; set; }
        public string SubDistrictNameEN { get; set; }
        public string ZipCode { get; set; }
    }
}