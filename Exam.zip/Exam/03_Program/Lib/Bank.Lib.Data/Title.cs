﻿namespace Bank.Lib.Data
{
    public class Title : CreateAndModifiedData
    {
        //public int Id { get; set; }
        public string TitleCode { get; set; }
        public string TitleNameTH { get; set; }
        public string TitleShortNameTH { get; set; }
        public string TitleNameEN { get; set; }
        public string TitleShortNameEN { get; set; }
    }
}