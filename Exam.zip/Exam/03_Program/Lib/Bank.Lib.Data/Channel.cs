﻿namespace Bank.Lib.Data
{
    public class Channel : CreateAndModifiedData
    {
        public string ChannelCode { get; set; }
        public string ChannelNameTH { get; set; }
        public string ChannelNameEN { get; set; }
    }
}