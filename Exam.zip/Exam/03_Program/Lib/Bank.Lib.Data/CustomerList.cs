﻿using System.Collections.Generic;

namespace Bank.Lib.Data
{
    public class CustomerList : ResultResponse
    {
        private List<Customer> _objectList = new List<Customer>();

        public List<Customer> ObjectList
        {
            get
            {
                return _objectList;
            }

            set
            {
                _objectList = value;
            }
        }
    }
}