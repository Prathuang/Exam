﻿namespace Bank.Lib.Data
{
    public class ResultResponse
    {
        private string _messageCode = string.Empty;
        private string _messageDesc = string.Empty;

        public string MessageCode
        {
            get { return _messageCode; }
            set { _messageCode = value; }
        }

        public string MessageDesc
        {
            get { return _messageDesc; }
            set { _messageDesc = value; }
        }
    }
}