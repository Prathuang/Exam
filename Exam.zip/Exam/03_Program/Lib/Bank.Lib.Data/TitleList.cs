﻿using System.Collections.Generic;

namespace Bank.Lib.Data
{
    public class TitleList : ResultResponse
    {
        private List<Title> _objectList = new List<Title>();

        public List<Title> ObjectList
        {
            get
            {
                return _objectList;
            }

            set
            {
                _objectList = value;
            }
        }
    }
}