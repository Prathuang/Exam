﻿namespace Bank.Lib.Data
{
    public class Branch : CreateAndModifiedData
    {
        public string BranchCode { get; set; }
        public string BranchNameTH { get; set; }
        public string BranchNameEN { get; set; }
        public string ChannelCode { get; set; }
        public string ProvinceCode { get; set; }
        public string DistrictCode { get; set; }
        public string SubDistrictCode { get; set; }
    }
}