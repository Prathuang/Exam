﻿using System.Collections.Generic;

namespace Bank.Lib.Data
{
    public class ChannelList : ResultResponse
    {
        private List<Channel> _objectList = new List<Channel>();

        public List<Channel> ObjectList
        {
            get
            {
                return _objectList;
            }

            set
            {
                _objectList = value;
            }
        }
    }
}