﻿namespace Bank.Lib.Data
{
    public class UserProfile
    {
        public ManageUser ManageUser { get; set; }

        //public string messageCode { get; set; }
        //public string messageDesc { get; set; }

        public string MessageLog { get; set; }

        public string Guid { get; set; }
        public string ClientIp { get; set; }
        public string HostIp { get; set; }

        public string MethodName { get; set; }
        public string ProgramName { get; set; }
    }
}