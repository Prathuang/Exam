﻿namespace Bank.Lib.Data
{
    public class ManageUser : CreateAndModifiedData
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        public string RoleCode { get; set; }

        public string FirstNameTH { get; set; }
        public string MiddleNameTH { get; set; }
        public string LastNameTH { get; set; }

        public string FirstNameEN { get; set; }
        public string MiddleNameEN { get; set; }
        public string LastNameEN { get; set; }
        public string BranchCode { get; set; }
    }
}