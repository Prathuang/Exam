﻿namespace Bank.Lib.Data
{
    public class Province : CreateAndModifiedData
    {
        public string ProvinceCode { get; set; }
        public string ProvinceNameTH { get; set; }
        public string ProvinceNameEN { get; set; }
    }
}