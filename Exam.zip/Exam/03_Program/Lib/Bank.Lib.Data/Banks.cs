﻿namespace Bank.Lib.Data
{
    public class Banks : CreateAndModifiedData
    {
        public string BanksCode { get; set; }
        public string BanksNameTH { get; set; }
        public string BanksNameEN { get; set; }
    }
}