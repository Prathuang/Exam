﻿namespace Bank.Lib.Data
{
    public class CustomerForSearch
    {
        public string AccountNo { get; set; }
        public string CitizenId { get; set; }
    }
}