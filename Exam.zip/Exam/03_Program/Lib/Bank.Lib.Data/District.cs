﻿namespace Bank.Lib.Data
{
    public class District : CreateAndModifiedData
    {
        public string ProvinceCode { get; set; }
        public string DistrictCode { get; set; }
        public string DistrictNameTH { get; set; }
        public string DistrictNameEN { get; set; }
    }
}