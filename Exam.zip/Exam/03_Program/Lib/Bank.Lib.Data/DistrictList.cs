﻿using System.Collections.Generic;

namespace Bank.Lib.Data
{
    public class DistrictList : ResultResponse
    {
        private List<District> _objectList = new List<District>();

        public List<District> ObjectList
        {
            get
            {
                return _objectList;
            }

            set
            {
                _objectList = value;
            }
        }
    }
}