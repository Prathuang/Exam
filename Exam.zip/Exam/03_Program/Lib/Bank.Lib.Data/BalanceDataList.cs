﻿using System.Collections.Generic;

namespace Bank.Lib.Data
{
    public class BalanceDataList : ResultResponse
    {
        private List<BalanceData> _objectList = new List<BalanceData>();

        public List<BalanceData> ObjectList
        {
            get
            {
                return _objectList;
            }

            set
            {
                _objectList = value;
            }
        }
    }
}