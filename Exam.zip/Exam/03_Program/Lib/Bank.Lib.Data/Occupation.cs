﻿namespace Bank.Lib.Data
{
    public class Occupation : CreateAndModifiedData
    {
        public string OccupationCode { get; set; }
        public string OccupationNameTH { get; set; }
        public string OccupationNameEN { get; set; }
    }
}