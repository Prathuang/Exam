﻿using EncrypDLL;

namespace Bank.Lib.DataSecurity
{
    public class EncryptDecrypt_MD5
    {
        private static string _key = "MYBANK";
        private static readonly EncrypDll encrypt = new EncrypDll();

        static public string GetEncrypt(string input)
        {
            return encrypt.Encrypt(input, _key, EncrypDll.MD5);
        }

        static public string GetDecrypt(string input)
        {
            return encrypt.Decrypt(input, _key, EncrypDll.MD5);
        }

        static public string GetEncrypt(string input, string key)
        {
            return encrypt.Encrypt(input, key, EncrypDll.MD5);
        }

        static public string GetDecrypt(string input, string key)
        {
            return encrypt.Decrypt(input, key, EncrypDll.MD5);
        }
    }
}
