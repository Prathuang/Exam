﻿using System.Collections.Generic;
namespace Bank.Lib.CallDB
{
    public class ResultInfo
    {
        private object _output = null;
        private bool _success = false;
        private string _errMsg = string.Empty;


        public object Output
        {
            get { return _output; }
            set { _output = value; }
        }

        public bool Success
        {
            get { return _success; }
            set { _success = value; }
        }

        public string ErrorMessage
        {
            get { return _errMsg; }
            set { _errMsg = value; }
        }
    }

    public class ResultValue<T> where T : struct
    {
        private string errorMessageField = string.Empty;
        private T outputField;
        private bool successField = false;

        public bool Success
        {
            get
            {
                return this.successField;
            }
            set
            {
                this.successField = value;
            }
        }

        public string ErrorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
            }
        }

        public T Output
        {
            get
            {
                return this.outputField;
            }
            set
            {
                if ((object.ReferenceEquals(this.outputField, value) != true))
                {
                    this.outputField = value;
                }
            }
        }
    }

    public class ResultNullableValue<T> where T : struct
    {
        private string errorMessageField = string.Empty;
        private T? outputField;
        private bool successField = false;

        public bool Success
        {
            get
            {
                return this.successField;
            }
            set
            {
                this.successField = value;
            }
        }

        public string ErrorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
            }
        }

        public T? Output
        {
            get
            {
                return this.outputField;
            }
            set
            {
                if ((object.ReferenceEquals(this.outputField, value) != true))
                {
                    this.outputField = value;
                }
            }
        }
    }

    public class ResultStringValue
    {
        private string errorMessageField = string.Empty;
        private string outputField;
        private bool successField = false;

        public bool Success
        {
            get
            {
                return this.successField;
            }
            set
            {
                this.successField = value;
            }
        }

        public string ErrorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
            }
        }

        public string Output
        {
            get
            {
                return this.outputField;
            }
            set
            {
                if ((object.ReferenceEquals(this.outputField, value) != true))
                {
                    this.outputField = value;
                }
            }
        }
    }

    public class ResultInfo<T> where T : class, new()
    {
        private string errorMessageField = string.Empty;
        private T outputField = null;
        private bool successField = false;

        public bool Success
        {
            get
            {
                return this.successField;
            }
            set
            {
                this.successField = value;
            }
        }

        public string ErrorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
            }
        }

        public T Output
        {
            get
            {
                return this.outputField;
            }
            set
            {
                if ((object.ReferenceEquals(this.outputField, value) != true))
                {
                    this.outputField = value;
                }
            }
        }
    }

    public class ResultInfoList<T> where T : class, new()
    {
        private string errorMessageField = string.Empty;
        private List<T> outputField = null;
        private bool successField = false;

        public bool Success
        {
            get
            {
                return this.successField;
            }
            set
            {
                this.successField = value;
            }
        }

        public string ErrorMessage
        {
            get
            {
                return this.errorMessageField;
            }
            set
            {
                this.errorMessageField = value;
            }
        }

        public List<T> Output
        {
            get
            {
                return this.outputField;
            }
            set
            {
                if ((object.ReferenceEquals(this.outputField, value) != true))
                {
                    this.outputField = value;
                }
            }
        }
    }
}