﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace Bank.Lib.CallDB
{
    public class StoredProcedureReader
    {
        public static void Read(string dbName, string storeName, IDictionary<string, object> parameters, Action<SqlDataReader> callback)
        {
            string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings[dbName].ConnectionString;
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand()
            {
                CommandText = storeName,
                CommandType = CommandType.StoredProcedure,
                Connection = sqlConnection
            };

            if (parameters != null && parameters.Count > 0)
            {
                foreach (KeyValuePair<string, object> keyValue in parameters)
                {
                    cmd.Parameters.AddWithValue("@" + keyValue.Key, keyValue.Value);
                }
            }

            sqlConnection.Open();

            SqlDataReader reader = cmd.ExecuteReader();
            callback(reader);
            sqlConnection.Close();
        }

        public static void Read(string dbName, string storeName, IDictionary<string, object> parameters, Action<DataSet> callback)
        {
            DataSet dsResult = new DataSet();
            string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings[dbName].ConnectionString;
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            try
            {
                SqlCommand cmd = new SqlCommand()
                {
                    CommandText = storeName,
                    CommandType = CommandType.StoredProcedure,
                    Connection = sqlConnection
                };

                if (parameters != null && parameters.Count > 0)
                {
                    foreach (KeyValuePair<string, object> keyValue in parameters)
                    {
                        cmd.Parameters.AddWithValue("@" + keyValue.Key, keyValue.Value);
                    }
                }

                sqlConnection.Open();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dsResult, "DSResult");
                sqlConnection.Close();
                cmd.Parameters.Clear();
            }
            catch (Exception ex)
            {
                dsResult = new DataSet();
                if (sqlConnection != null)
                {
                    sqlConnection.Close();
                }
            }
            finally
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
                callback(dsResult);
            }
        }

        public static void ExecStored(string dbName, string storeName, IDictionary<string, object> parameters, Action<bool> callback)
        {
            bool success = false;
            string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings[dbName].ConnectionString;
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            try
            {
                SqlCommand cmd = new SqlCommand()
                {
                    CommandText = storeName,
                    CommandType = CommandType.StoredProcedure,
                    Connection = sqlConnection
                };

                if (parameters != null && parameters.Count > 0)
                {
                    foreach (KeyValuePair<string, object> keyValue in parameters)
                    {
                        cmd.Parameters.AddWithValue("@" + keyValue.Key, keyValue.Value);
                    }
                }
                sqlConnection.Open();
                int result = cmd.ExecuteNonQuery();
                sqlConnection.Close();
                cmd.Parameters.Clear();
                if (result >= 0)
                {
                    success = true;
                }
            }
            catch (Exception ex)
            {
                success = false;
                if (sqlConnection != null)
                {
                    sqlConnection.Close();
                }
            }
            finally
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
                callback(success);
            }
        }

        public static void ExecStoredWithParameterOut(string dbName, string storeName, IDictionary<string, object> parametersIn, List<SqlParameter> oraParamsOut, Action<Dictionary<string, object>> callback)
        {
            bool success = false;
            Dictionary<string, object> parametersOut = new Dictionary<string, object>();
            string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings[dbName].ConnectionString;
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            try
            {
                SqlCommand cmd = new SqlCommand()
                {
                    CommandText = storeName,
                    CommandType = CommandType.StoredProcedure,
                    Connection = sqlConnection
                };

                if (parametersIn != null && parametersIn.Count > 0)
                {
                    foreach (KeyValuePair<string, object> keyValue in parametersIn)
                    {
                        cmd.Parameters.AddWithValue("@" + keyValue.Key, keyValue.Value);
                    }
                }

                if (oraParamsOut != null && oraParamsOut.Count() > 0)
                {
                    cmd.Parameters.AddRange(oraParamsOut.ToArray());
                }

                sqlConnection.Open();
                int result = cmd.ExecuteNonQuery();
                if (result >= 0)
                {
                    success = true;
                    parametersOut.Add("Success", success);
                    if (success)
                    {
                        for (int i = 0; i < oraParamsOut.Count(); i++)
                        {
                            parametersOut.Add(oraParamsOut[i].ParameterName, cmd.Parameters[oraParamsOut[i].ParameterName].Value.ToString());
                        }
                    }
                }
                sqlConnection.Close();
                cmd.Parameters.Clear();
            }
            catch (Exception ex)
            {
                success = false;
                parametersOut.Add("Success", success);
                if (sqlConnection != null)
                {
                    sqlConnection.Close();
                }
            }
            finally
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
                callback(parametersOut);
            }
        }

        public static void ExecStored(string dbName, string storeName, IDictionary<string, object> parameters, Action<ResultStringValue> callback)
        {
            ResultStringValue response = new ResultStringValue();
            string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings[dbName].ConnectionString;
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            try
            {
                SqlCommand cmd = new SqlCommand()
                {
                    CommandText = storeName,
                    CommandType = CommandType.StoredProcedure,
                    Connection = sqlConnection
                };

                if (parameters != null && parameters.Count > 0)
                {
                    foreach (KeyValuePair<string, object> keyValue in parameters)
                    {
                        cmd.Parameters.AddWithValue("@" + keyValue.Key, keyValue.Value);
                    }
                }
                sqlConnection.Open();
                int result = cmd.ExecuteNonQuery();
                sqlConnection.Close();
                cmd.Parameters.Clear();
                if (result >= 0)
                {
                    response.Success = true;
                }
            }
            catch (Exception ex)
            {
                //success = false;
                response.Success = false;
                response.Output = ex.Message;
                if (sqlConnection != null)
                {
                    sqlConnection.Close();
                }
            }
            finally
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
                callback(response);
            }
        }

    }
}