﻿using System;
using System.IO;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Text;

namespace Bank.Lib.CallRestfulAPI
{
    public class CallRestfulAPI
    {
        public virtual int Timeout { get; private set; }
        public virtual string Uri { get; private set; }

        public CallRestfulAPI(string uri, int timeout)
        {
            this.Uri = uri;
            this.Timeout = timeout;
        }

        public DataTypeResponse CallAPI<DataTypeResponse, DataTypeRequest>(DataTypeRequest request, ref bool isSuccess, ref string errorMessage)
        {
            DataTypeResponse response = default(DataTypeResponse);
            response = Activator.CreateInstance<DataTypeResponse>();
            try
            {
                isSuccess = false;
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(this.Uri);
                using (req as IDisposable)
                {
                    req.Method = "POST";
                    req.ContentType = @"application/json";
                    req.Timeout = this.Timeout;

                    DataContractJsonSerializer serReq = new DataContractJsonSerializer(typeof(DataTypeRequest));
                    MemoryStream stream = new MemoryStream();

                    serReq.WriteObject(stream, request);
                    string data = Encoding.UTF8.GetString(stream.ToArray(), 0, (int)stream.Length);

                    UTF8Encoding encoding = new UTF8Encoding();
                    Byte[] content = encoding.GetBytes(data.ToString());
                    req.ContentLength = content.Length;

                    using (Stream dataStream = req.GetRequestStream())
                    {
                        dataStream.Write(content, 0, content.Length);

                        using (HttpWebResponse res = (HttpWebResponse)req.GetResponse())
                        {
                            if (res.StatusCode == HttpStatusCode.OK)
                            {
                                DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(DataTypeResponse));
                                object objResponse = ser.ReadObject(res.GetResponseStream());
                                response = (DataTypeResponse)objResponse;
                                isSuccess = true;
                            }
                            else
                            {
                                errorMessage = "Unable to connect Service";
                            }

                            res.Close();
                        }
                        dataStream.Close();
                        dataStream.Dispose();
                    }
                }
            }
            catch (Exception ex)
            {
                isSuccess = false;
                errorMessage = ex.Message;
            }
            return response;
        }

        public string GetStringAPI(ref bool isSuccess, ref string errorMessage)
        {
            string response = string.Empty;
            try
            {
                isSuccess = false;
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(this.Uri);
                using (req as IDisposable)
                {
                    req.Method = "POST";
                    req.ContentType = @"application/json";
                    req.Timeout = this.Timeout;

                    DataContractJsonSerializer serReq = new DataContractJsonSerializer(typeof(string));
                    MemoryStream stream = new MemoryStream();

                    serReq.WriteObject(stream, string.Empty);
                    string data = Encoding.UTF8.GetString(stream.ToArray(), 0, (int)stream.Length);

                    UTF8Encoding encoding = new UTF8Encoding();
                    Byte[] content = encoding.GetBytes(data.ToString());
                    req.ContentLength = content.Length;

                    using (Stream dataStream = req.GetRequestStream())
                    {
                        dataStream.Write(content, 0, content.Length);

                        using (HttpWebResponse res = (HttpWebResponse)req.GetResponse())
                        {
                            if (res.StatusCode == HttpStatusCode.OK)
                            {
                                using (StreamReader reader = new StreamReader(res.GetResponseStream(), encoding, true))
                                {
                                    response = reader.ReadToEnd();
                                    isSuccess = true;
                                }
                            }
                            else
                            {
                                errorMessage = "Unable to connect Service";
                            }

                            res.Close();
                        }
                        dataStream.Close();
                        dataStream.Dispose();
                    }
                }
            }
            catch (Exception ex)
            {
                isSuccess = false;
                errorMessage = ex.Message;
            }
            return response;
        }
    }
}