﻿using System;

namespace Bank.Lib.ConfigurationXML
{
    public class Response
    {
        #region Fields
        private InterfaceResponse _inf;
        private String _code, _messageCode, _messageDesc;
        #endregion

        #region Properties
        public InterfaceResponse Interface
        {
            get { return _inf; }
        }

        public String Code
        {
            get { return _code; }
        }

        public String MessageCode
        {
            get { return _messageCode; }
        }

        public String MessageDesc
        {
            get { return _messageDesc; }
        }

        #endregion

        #region Constructors
        internal Response(InterfaceResponse inf, String code, String messageCode, String messageDesc)
        {
            _inf = inf;
            _code = code;
            _messageCode = messageCode;
            _messageDesc = messageDesc;
        }

        internal Response(InterfaceResponse inf, String messageCode, String messageDesc)
        {
            _inf = inf;
            _messageCode = messageCode;
            _messageDesc = messageDesc;
        }
        #endregion

        #region overrided
        public override string ToString()
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            if (string.IsNullOrEmpty(Code))
            {
                sb.AppendFormat("[MessageCode={0}:MessageDesc={1}:Interface={2}]", MessageCode, MessageDesc, Interface.ToString());
            }
            else
            {
                sb.AppendFormat("[Code={0}:MessageCode={1}:MessageDesc={2}:Interface={3}]", Code, MessageCode, MessageDesc, Interface.ToString());
            }

            return sb.ToString();
        }
        #endregion
    }
}