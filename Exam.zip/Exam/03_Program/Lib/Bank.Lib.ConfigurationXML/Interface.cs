﻿namespace Bank.Lib.ConfigurationXML
{
    public enum InterfaceResponse
    {
        ResponseService,
        ResponseTimeout
    }

    public enum MessageCode
    {
        Success,
        DataNotFound,
        Error,
        Unauthorized,
        CannotSave,
        Timeout
    }

    public enum InterfaceServiceName
    {
        CallIBANNumber,

        GetAllMaster,
        GetBanksList,
        GetBranchList,
        GetChannelList,
        GetSubDistrictList,
        GetDistrictList,

        GetProvinceList,
        GetOccupationList,
        GetTitleList,
        GetTypeFinancialList,

        CheckUserLogin,
        InsertCustomer,
        CheckCustomer,

        InsertFinancialTransaction,
        GetBalanceData
    }
}