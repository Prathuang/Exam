﻿using System;
using System.Xml.Linq;

namespace Bank.Lib.ConfigurationXML
{
    public class ApiConfiguration
    {
        #region Properties
        public ApiConfig ApiConfig { get; private set; }
        #endregion

        #region Constructors
        public ApiConfiguration()
        {
        }
        public ApiConfiguration(String uri)
        {
            XDocument xDoc = XDocument.Load(uri);
            ApiConfig = new ApiConfig(xDoc.Descendants("Services"));
        }
        #endregion
    }
}