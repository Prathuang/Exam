﻿using Bank.Lib.Data;
using System;
using System.Collections.Generic;
namespace Bank.Lib.Business
{
    public class BanksBusiness : InitialData
    {
        //private string _messageLog = string.Empty;

        //private string _guid;
        //private string _clientIp = string.Empty;
        //private string _hostIp = string.Empty;
        
        //private string _methodName = string.Empty;
        //private string _programName = string.Empty;

        public BanksBusiness(string programName, string guid, string clientIp, string hostIp)
        {
            try
            {
                _messageLog = "{0}|{1}|{2}|{3}| {4}";//"Guid:{0}|ClientIp:{1}|HostIp:{2}|MethodName:{3}| Message:{4}" //DoBusiness.GetMessageLog;
                _programName = programName;

                _clientIp = clientIp;
                _hostIp = hostIp;
                _guid = _hostIp.Split('.')[3].PadLeft(3, '0') + "-" + guid;
                System.Configuration.ConfigurationManager.RefreshSection("appSettings");
                
                InitialWriteLogFile.Initial(programName);
            }
            catch { }
        }

        public string GetIBANNumber()
        {
            string response = string.Empty;
            try
            {
                bool isSuccess = false;
                string errorMessage = string.Empty;
                Bank.Lib.Business.Cache loadCache = new Bank.Lib.Business.Cache(_programName, _guid, _clientIp, _hostIp);
                Bank.Lib.CallRestfulAPI.CallRestfulAPI process = new Bank.Lib.CallRestfulAPI.CallRestfulAPI(loadCache.ApiConfiguration.ApiConfig.Service["CallIBANNumber"].Url, loadCache.ApiConfiguration.ApiConfig.Service["CallIBANNumber"].Timeout);
                response = process.GetStringAPI( ref isSuccess, ref errorMessage);
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger("BankBusiness").Error("Insert => Error Message : " + ex.Message);
            }

            return response;
        }

        //public List<Banks> GetBankslist()
        //{
        //    _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
        //    log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
        //    DateTime StartTime = DateTime.Now;
        //    List<Banks> response = new List<Banks>();
        //    try
        //    {
        //        Bank.Lib.Business.Cache loadCache = new Bank.Lib.Business.Cache(_programName, _guid, _clientIp, _hostIp);
        //        response = loadCache.AllBanks;
        //    }
        //    catch (Exception ex)
        //    {
        //        log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
        //    }
        //    finally
        //    {
        //        log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
        //    }

        //    return response;
        //}

        //public List<Banks> GetAllBankslist()
        //{
        //    _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
        //    log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, "Start GetBankslist");
        //    DateTime StartTime = DateTime.Now;
        //    List<Banks> response = new List<Banks>();
        //    try
        //    {
        //        StoredProcedureReader.Read(StoredProcedureName.SQLConnStringDB, StoredProcedureName.Banks.SPName_SP_BANK_GET_BANKS, null, (ds) =>
        //        {
        //            if (ds != null && ds.Tables[0].Rows.Count > 0)
        //            {
        //                response = ds.Tables[0] != null ? NewExtension.ConvertDataTableToList<Banks>(ds.Tables[0]) : Enumerable.Empty<Banks>().ToList();
        //            }
        //        });
        //    }
        //    catch (Exception ex)
        //    {
        //        log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, "GetBankslist => Error Message : " + ex.Message);
        //    }
        //    finally
        //    {
        //        log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End GetBankslist => Total Process: {0} ms.", ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
        //    }

        //    return response;
        //}
    }
}
