﻿using Bank.Lib.CallDB;
using Bank.Lib.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bank.Lib.CallRestfulAPI;
namespace Bank.Lib.Business
{
    public class BankBusiness
    {
        public static string GetIBANNumber()
        {
            string response = string.Empty;
            try
            {
                bool isSuccess = false;
                string errorMessage = string.Empty;
                Bank.Lib.Business.Cache loadCache = new Bank.Lib.Business.Cache();
                Bank.Lib.CallRestfulAPI.CallRestfulAPI process = new Bank.Lib.CallRestfulAPI.CallRestfulAPI(loadCache.ApiConfiguration.ApiConfig.Service["CallIBANNumber"].Url, loadCache.ApiConfiguration.ApiConfig.Service["CallIBANNumber"].Timeout);
                response = process.GetStringAPI( ref isSuccess, ref errorMessage);
            }
            catch (Exception ex)
            {
                //response.Success = false;
                //response.ErrorMessage = ex.Message;
                InitialWriteLogFile.Initial();
                log4net.LogManager.GetLogger("BankBusiness").Debug("Insert => Error Message : " + ex.Message);
            }

            return response;
        }
    }
}
