﻿using System;

namespace Bank.Lib.Business
{
    class LoadCache
    {
        private string _className = System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.FullName;
        private string _messageLog = "{0}|{1}|{2}|{3}";//"Program:{0}|Class:{1}|Method:{2}|{3}"

        public Bank.Lib.Business.Cache loadCache(String programName, string guid, string clientIp, string hostIp)
        {
            #region Load Cache
            Bank.Lib.Business.Cache cache;
            string methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            long _start = DateTime.Now.Ticks;
            try
            {
                log4net.LogManager.GetLogger(programName).InfoFormat(_messageLog, guid, clientIp, hostIp, methodName, "Load Cache Start");
                cache = new Bank.Lib.Business.Cache(programName, guid, clientIp, hostIp);
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(programName).InfoFormat(_messageLog, guid, clientIp, hostIp, methodName, string.Format("Load Cache Error: '{0}' ", ex.Message));
                throw new Exception(ex.Message);
            }
            finally
            {
                log4net.LogManager.GetLogger(programName).InfoFormat(_messageLog, guid, clientIp, hostIp, methodName, string.Format("Load Cache End (Total Time : {0:F0} ms.)", new TimeSpan(DateTime.Now.Ticks - _start).TotalMilliseconds));
            }
            #endregion
            return cache;
        }
    }
}