﻿using System;
using System.Data;
using System.Web;
using System.Web.Caching;
using System.Linq;
using System.IO;
using System.Collections.Generic;
using Bank.Lib.Data;
using Bank.Lib.ConfigurationXML;

namespace Bank.Lib.Business
{
    public class Cache
    {
        #region Fields
        private XResponse _xResponse;
        private ApiConfiguration _ApiConfiguration;

        private List<Banks> _AllBanks = new List<Banks>();
        private List<Branch> _AllBranch = new List<Branch>();
        private List<Channel> _AllChannel = new List<Channel>();
        private List<SubDistrict> _AllSubDistrict = new List<SubDistrict>();
        private List<District> _AllDistrict = new List<District>();

        private List<Province> _AllProvince = new List<Province>();
        private List<Occupation> _AllOccupation = new List<Occupation>();
        private List<Title> _AllTitle = new List<Title>();
        private List<TypeFinancial> _AllTypeFinancial = new List<TypeFinancial>();
        private List<ManageUser> _AllManageUser = new List<ManageUser>();
        #endregion

        #region Properties
        public XResponse XResponse
        {
            get { return _xResponse; }
        }

        public ApiConfiguration ApiConfiguration
        {
            get { return _ApiConfiguration; }
        }

        public List<Banks> AllBanks
        {
            get { return _AllBanks; }
        }

        public List<Branch> AllBranch
        {
            get
            {
                return _AllBranch;
            }
        }

        public List<Channel> AllChannel
        {
            get
            {
                return _AllChannel;
            }
        }

        public List<SubDistrict> AllSubDistrict
        {
            get
            {
                return _AllSubDistrict;
            }
        }

        public List<District> AllDistrict
        {
            get
            {
                return _AllDistrict;
            }
        }

        public List<Province> AllProvince
        {
            get
            {
                return _AllProvince;
            }
        }

        public List<Occupation> AllOccupation
        {
            get
            {
                return _AllOccupation;
            }
        }

        public List<Title> AllTitle
        {
            get
            {
                return _AllTitle;
            }
        }

        public List<TypeFinancial> AllTypeFinancial
        {
            get
            {
                return _AllTypeFinancial;
            }
        }

        public List<ManageUser> AllManageUser
        {
            get
            {
                return _AllManageUser;
            }

            set
            {
                _AllManageUser = value;
            }
        }
        #endregion

        #region Constructors

        private DataTable CreatDataTable()
        {
            DataTable dt = new DataTable("Detail");
            dt.Clear();
            dt.Columns.Add("CheckKey");
            dt.Columns.Add("LastModified");
            return dt;
        }

        private string ResponseUri = string.Empty;
        private string ApiConfigUri = string.Empty;
        public Cache(string programName, string guid, string clientIp, string hostIp)
        {
            String key = String.Empty;
            LoadCacheBusiness bs = new Business.LoadCacheBusiness(programName, guid, clientIp, hostIp);
            try
            {
                ResponseUri = HttpContext.Current.Server.MapPath("~/App_Data/Response.xml");
            }
            catch { }

            try
            {
                ApiConfigUri = HttpContext.Current.Server.MapPath("~/App_Data/ApiConfig.xml");
            }
            catch { }

            if (string.IsNullOrEmpty(ResponseUri))
            {
                ResponseUri = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"App_Data\Response.xml");
            }

            if (string.IsNullOrEmpty(ApiConfigUri))
            {
                ApiConfigUri = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"App_Data\ApiConfig.xml");
            }

            #region New Load Cache
            DataTable dtChache = new DataTable();
            bool IsLoad = false;
            key = "BANK.MODIFIEDFILE";
            if (HttpContext.Current.Cache[key] != null)
            {
                IsLoad = true;
                dtChache = HttpContext.Current.Cache[key] as DataTable;
            }

            string pathFile = HttpContext.Current.Server.MapPath("~/App_Data/");
            List<string> ListXmlPathFile = Directory.GetFiles(pathFile, "*.xml").ToList();
            DataTable dt = CreatDataTable();

            if (ListXmlPathFile.Count > 0)
            {
                for (int i = 0; i < ListXmlPathFile.Count; i++)
                {
                    DataRow dr = dt.NewRow();

                    FileInfo fileName = new FileInfo(ListXmlPathFile[i]);
                    string FileNameWithoutExtension = Path.GetFileNameWithoutExtension(fileName.FullName);
                    string name = fileName.Name;
                    var created = fileName.CreationTime; //File Creation
                    var lastmodified = fileName.LastWriteTime;//File Modification

                    dr["CheckKey"] = "BANK." + FileNameWithoutExtension.ToUpper();
                    dr["LastModified"] = lastmodified.ToString("yyyyMMdd HH:mm:ss", new System.Globalization.CultureInfo("en-US"));

                    dt.Rows.Add(dr);
                }
            }

            if (IsLoad)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    string CheckKey = dt.Rows[i]["CheckKey"].ToString();
                    string LastModified = dt.Rows[i]["LastModified"].ToString();
                    IEnumerable<DataRow> filteredData = (from P in dtChache.AsEnumerable()
                                                         where (P.Field<string>("CheckKey") == CheckKey) && (P.Field<string>("LastModified") == LastModified)
                                                         select P);

                    if (!filteredData.Any())
                    {
                        key = CheckKey;
                        if (HttpContext.Current.Cache[key] != null)
                        {
                            HttpContext.Current.Cache.Remove(key);
                        }
                        if (CheckKey.ToUpper().Equals("BANK.RESPONSE"))
                        {
                            _xResponse = new XResponse(ResponseUri);
                            HttpContext.Current.Cache.Add(key, _xResponse, new CacheDependency(ResponseUri), System.Web.Caching.Cache.NoAbsoluteExpiration, System.Web.Caching.Cache.NoSlidingExpiration, CacheItemPriority.Default, null);
                        }
                        if (CheckKey.ToUpper().Equals("BANK.APICONFIG"))
                        {
                            _ApiConfiguration = new ApiConfiguration(ApiConfigUri);
                            HttpContext.Current.Cache.Add(key, _ApiConfiguration, new CacheDependency(ApiConfigUri), System.Web.Caching.Cache.NoAbsoluteExpiration, System.Web.Caching.Cache.NoSlidingExpiration, CacheItemPriority.Default, null);
                        }
                    }
                }
            }

            key = "BANK.MODIFIEDFILE";
            HttpContext.Current.Cache.Remove(key);
            if (dt != null && dt.Rows.Count > 0)
            {
                dtChache = dt;
            }
            HttpContext.Current.Cache.Add(key, dtChache, null, System.Web.Caching.Cache.NoAbsoluteExpiration, System.Web.Caching.Cache.NoSlidingExpiration, CacheItemPriority.Default, null);
            #endregion

            #region Response
            key = "BANK.RESPONSE";
            if (HttpContext.Current.Cache[key] != null)
            {
                _xResponse = HttpContext.Current.Cache[key] as XResponse;
            }
            else
            {
                _xResponse = new XResponse(ResponseUri);
                HttpContext.Current.Cache.Add(key, _xResponse, new CacheDependency(ResponseUri), System.Web.Caching.Cache.NoAbsoluteExpiration, System.Web.Caching.Cache.NoSlidingExpiration, CacheItemPriority.Default, null);
            }
            #endregion

            #region APICONFIG
            key = "BANK.APICONFIG";
            if (HttpContext.Current.Cache[key] != null)
            {
                _ApiConfiguration = HttpContext.Current.Cache[key] as ApiConfiguration;
            }
            else
            {
                _ApiConfiguration = new ApiConfiguration(ApiConfigUri);
                HttpContext.Current.Cache.Add(key, _ApiConfiguration, new CacheDependency(ApiConfigUri), System.Web.Caching.Cache.NoAbsoluteExpiration, System.Web.Caching.Cache.NoSlidingExpiration, CacheItemPriority.Default, null);
            }
            #endregion

            #region AllBanks
            key = "BANK.ALLBANKS";
            if (HttpContext.Current.Cache[key] != null)
            {
                _AllBanks = HttpContext.Current.Cache[key] as List<Banks>;
            }
            else
            {
                _AllBanks = bs.LoadCacheAllBanksList();
                HttpContext.Current.Cache.Add(key, _AllBanks, null, System.Web.Caching.Cache.NoAbsoluteExpiration, TimeSpan.FromMinutes(10), CacheItemPriority.Default, null);
            }
            #endregion

            #region AllBranch
            key = "BANK.ALLBRANCH";
            if (HttpContext.Current.Cache[key] != null)
            {
                _AllBranch = HttpContext.Current.Cache[key] as List<Branch>;
            }
            else
            {
                _AllBranch = bs.LoadCacheAllBranchList();
                HttpContext.Current.Cache.Add(key, _AllBranch, null, System.Web.Caching.Cache.NoAbsoluteExpiration, TimeSpan.FromMinutes(10), CacheItemPriority.Default, null);
            }
            #endregion

            #region AllChannel
            key = "BANK.ALLCHANNEL";
            if (HttpContext.Current.Cache[key] != null)
            {
                _AllChannel = HttpContext.Current.Cache[key] as List<Channel>;
            }
            else
            {
                _AllChannel = bs.LoadCacheAllChannelList();
                HttpContext.Current.Cache.Add(key, _AllChannel, null, System.Web.Caching.Cache.NoAbsoluteExpiration, TimeSpan.FromMinutes(10), CacheItemPriority.Default, null);
            }
            #endregion

            #region AllSubDistrict
            key = "BANK.ALLSUBDISTRICT";
            if (HttpContext.Current.Cache[key] != null)
            {
                _AllSubDistrict = HttpContext.Current.Cache[key] as List<SubDistrict>;
            }
            else
            {
                _AllSubDistrict = bs.LoadCacheAllSubDistrictList();
                HttpContext.Current.Cache.Add(key, _AllSubDistrict, null, System.Web.Caching.Cache.NoAbsoluteExpiration, TimeSpan.FromMinutes(10), CacheItemPriority.Default, null);
            }
            #endregion

            #region AllDistrict
            key = "BANK.ALLDISTRICT";
            if (HttpContext.Current.Cache[key] != null)
            {
                _AllDistrict = HttpContext.Current.Cache[key] as List<District>;
            }
            else
            {
                _AllDistrict = bs.LoadCacheAllDistrictList();
                HttpContext.Current.Cache.Add(key, _AllDistrict, null, System.Web.Caching.Cache.NoAbsoluteExpiration, TimeSpan.FromMinutes(10), CacheItemPriority.Default, null);
            }
            #endregion

            #region AllProvince
            key = "BANK.ALLPROVINCE";
            if (HttpContext.Current.Cache[key] != null)
            {
                _AllProvince = HttpContext.Current.Cache[key] as List<Province>;
            }
            else
            {
                _AllProvince = bs.LoadCacheAllProvinceList();
                HttpContext.Current.Cache.Add(key, _AllProvince, null, System.Web.Caching.Cache.NoAbsoluteExpiration, TimeSpan.FromMinutes(10), CacheItemPriority.Default, null);
            }
            #endregion

            #region AllOccupation
            key = "BANK.ALLOCCUPATION";
            if (HttpContext.Current.Cache[key] != null)
            {
                _AllOccupation = HttpContext.Current.Cache[key] as List<Occupation>;
            }
            else
            {
                _AllOccupation = bs.LoadCacheAllOccupationList();
                HttpContext.Current.Cache.Add(key, _AllOccupation, null, System.Web.Caching.Cache.NoAbsoluteExpiration, TimeSpan.FromMinutes(10), CacheItemPriority.Default, null);
            }
            #endregion

            #region AllTitle
            key = "BANK.ALLTITLE";
            if (HttpContext.Current.Cache[key] != null)
            {
                _AllTitle = HttpContext.Current.Cache[key] as List<Title>;
            }
            else
            {
                _AllTitle = bs.LoadCacheAllTitleList();
                HttpContext.Current.Cache.Add(key, _AllTitle, null, System.Web.Caching.Cache.NoAbsoluteExpiration, TimeSpan.FromMinutes(10), CacheItemPriority.Default, null);
            }
            #endregion

            #region AllTypeFinancial
            key = "BANK.ALLTYPEFINANCIAL";
            if (HttpContext.Current.Cache[key] != null)
            {
                _AllTypeFinancial = HttpContext.Current.Cache[key] as List<TypeFinancial>;
            }
            else
            {
                _AllTypeFinancial = bs.LoadCacheAllTypeFinancialList();
                HttpContext.Current.Cache.Add(key, _AllTypeFinancial, null, System.Web.Caching.Cache.NoAbsoluteExpiration, TimeSpan.FromMinutes(10), CacheItemPriority.Default, null);
            }
            #endregion

            #region AllManageUser
            key = "BANK.ALLMANAGEUSER";
            if (HttpContext.Current.Cache[key] != null)
            {
                _AllManageUser = HttpContext.Current.Cache[key] as List<ManageUser>;
            }
            else
            {
                _AllManageUser = bs.LoadCacheAllManageUserList();
                HttpContext.Current.Cache.Add(key, _AllManageUser, null, System.Web.Caching.Cache.NoAbsoluteExpiration, TimeSpan.FromMinutes(10), CacheItemPriority.Default, null);
            }
            #endregion

        }

        #endregion
    }
}