﻿namespace Bank.Lib.Business
{
    public class InitialData
    {
        public Bank.Lib.Business.Cache loadCache = null;

        public string messageCode = string.Empty;
        public string messageDesc = string.Empty;

        public string _messageLog = string.Empty;

        public string _guid = string.Empty;
        public string _clientIp = string.Empty;
        public string _hostIp = string.Empty;

        public string _methodName = string.Empty;
        public string _programName = string.Empty;
    }
}