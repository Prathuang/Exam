﻿namespace Bank.Lib.Business.ConnectDB
{
    public static class StoredProcedureName
    {
        public static readonly string SQLConnStringDB = "SQLConnString";

        public struct Banks
        {
            public static readonly string SPName_SP_BANK_GET_BANKS = "SP_BANK_GET_BANKS";
        }

        public struct Branch
        {
            public static readonly string SPName_SP_BANK_GET_BRANCH = "SP_BANK_GET_BRANCH";
        }

        public struct Channel
        {
            public static readonly string SPName_SP_BANK_GET_CHANNEL = "SP_BANK_GET_CHANNEL";
        }

        public struct SubDistrict
        {
            public static readonly string SPName_SP_BANK_GET_SUBDISTRICT = "SP_BANK_GET_SUBDISTRICT";
        }

        public struct District
        {
            public static readonly string SPName_SP_BANK_GET_DISTRICT = "SP_BANK_GET_DISTRICT";
        }

        public struct Province
        {
            public static readonly string SPName_SP_BANK_GET_PROVINCE = "SP_BANK_GET_PROVINCE";
        }

        public struct Occupation
        {
            public static readonly string SPName_SP_BANK_GET_OCCUPATION = "SP_BANK_GET_OCCUPATION";
        }

        public struct Title
        {
            public static readonly string SPName_SP_BANK_GET_TITLE = "SP_BANK_GET_TITLE";
        }

        public struct TypeFinancial
        {
            public static readonly string SPName_SP_BANK_GET_TYPE_FINANCIAL = "SP_BANK_GET_TYPE_FINANCIAL";
        }

        public struct Customer
        {
            public static readonly string SPName_SP_BANK_GET_CUSTOMER = "SP_BANK_GET_CUSTOMER";
            public static readonly string SPName_SP_BANK_INS_CUSTOMER = "SP_BANK_INS_CUSTOMER";
        }

        public struct ManageUser
        {
            public static readonly string SPName_SP_BANK_GET_MANAGE_USER = "SP_BANK_GET_MANAGE_USER";
        }

        public struct FinancialTransaction
        {
            public static readonly string SPName_SP_BANK_SET_BALANCE_TRANSACTION = "SP_BANK_SET_BALANCE_TRANSACTION";
        }

        public struct Balance
        {
            public static readonly string SPName_SP_BANK_GET_BALANCE = "SP_BANK_GET_BALANCE";
        }
    }
}