﻿namespace Bank.Lib.Business
{
    public enum InterfaceResponse
    {
        ResponseService,
        ResponseTimeout
    }

    public enum MessageCode
    {
        Success,
        Fail,
        Error,
        Unauthorized,
        Timeout
    }

    public enum InterfaceServiceName
    {
        CallIBANNumber
    }
}