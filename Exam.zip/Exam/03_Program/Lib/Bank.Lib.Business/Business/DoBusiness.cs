﻿namespace Bank.Lib.Business
{
    public class DoBusiness
    {
        public static string GetHostIp
        {
            get
            {
                try
                {
                    string hostname = System.Net.Dns.GetHostName();
                    string hostip = "";
                    System.Net.IPAddress[] ip_addr = System.Net.Dns.GetHostEntry(hostname).AddressList;

                    for (int i = 0; i < ip_addr.Length; i++)
                    {
                        if (ip_addr[i].AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                        {
                            hostip = ip_addr[i].ToString();
                            break;
                        }
                    }
                    return hostip;
                }
                catch
                {
                    return "";
                }
            }
        }

        public static string GetMessageLog
        {
            get
            {
                return "{0}|{1}|{2}|{3}| {4}";//"Guid:{0}|ClientIp:{1}|HostIp:{2}|MethodName:{3}| Message:{4}"
            }
        }
    }
}