﻿using System;
using Bank.Lib.Data;
using System.Linq;
using Bank.Lib.ConfigurationXML;

namespace Bank.Lib.Business
{
    public class LoginBusiness : InitialData
    {
        public LoginBusiness(string programName, string guid, string clientIp, string hostIp)
        {
            try
            {
                _messageLog = DoBusiness.GetMessageLog;
                _programName = programName;

                _clientIp = clientIp;
                _hostIp = hostIp;
                _guid = _hostIp.Split('.')[3].PadLeft(3, '0') + "-" + guid;
                System.Configuration.ConfigurationManager.RefreshSection("appSettings");

                InitialWriteLogFile.Initial(programName);
            }
            catch { }
        }

        public ManageUserList CheckUserLogin(ManageUser request)
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;
            ManageUserList response = new ManageUserList();
            try
            {
                loadCache = new Bank.Lib.Business.Cache(_programName, _guid, _clientIp, _hostIp);
                if (loadCache.AllManageUser != null && loadCache.AllManageUser.Count > 0)
                {
                    string requestPasswordDecrypt = Bank.Lib.DataSecurity.EncryptDecrypt_MD5.GetDecrypt(request.Password);

                    var checkUserLogin = loadCache.AllManageUser.Where(x => x.UserName.Equals(request.UserName) && Bank.Lib.DataSecurity.EncryptDecrypt_MD5.GetDecrypt(x.Password).Equals(requestPasswordDecrypt)).ToList();
                    if (checkUserLogin != null && checkUserLogin.Count > 0)
                    {
                        messageCode = MessageCode.Success.ToString();
                        response.ObjectList = checkUserLogin;
                    }
                    else
                    {
                        messageCode = MessageCode.Unauthorized.ToString();
                    }
                }
                else
                {
                    messageCode = MessageCode.DataNotFound.ToString();
                }
            }
            catch (Exception ex)
            {
                messageCode = MessageCode.Error.ToString();
                messageDesc = ex.Message;
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                Response ResponseXml = Bank.Lib.Business.ResponseBusiness.MakeResponse(loadCache, InterfaceResponse.ResponseService, messageCode, messageDesc);
                response.MessageCode = ResponseXml.MessageCode;
                response.MessageDesc = ResponseXml.MessageDesc;

                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }
    }
}