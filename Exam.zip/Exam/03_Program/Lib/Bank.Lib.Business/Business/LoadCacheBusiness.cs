﻿using System;
using System.Collections.Generic;
using Bank.Lib.Data;
using Bank.Lib.CallDB;
using Bank.Lib.Business.ConnectDB;
using System.Linq;

namespace Bank.Lib.Business
{
    internal class LoadCacheBusiness : InitialData
    {
        public LoadCacheBusiness(string programName, string guid, string clientIp, string hostIp)
        {
            try
            {
                _messageLog = DoBusiness.GetMessageLog;
                _programName = programName;

                _clientIp = clientIp;
                _hostIp = hostIp;
                _guid = guid;
                System.Configuration.ConfigurationManager.RefreshSection("appSettings");

                InitialWriteLogFile.Initial(programName);
            }
            catch { }
        }

        public List<Banks> LoadCacheAllBanksList()
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, "Start " + _methodName);
            DateTime StartTime = DateTime.Now;
            List<Banks> response = new List<Banks>();
            try
            {
                StoredProcedureReader.Read(StoredProcedureName.SQLConnStringDB, StoredProcedureName.Banks.SPName_SP_BANK_GET_BANKS, null, (ds) =>
                {
                    if (ds != null && ds.Tables[0].Rows.Count > 0)
                    {
                        response = ds.Tables[0] != null ? NewExtension.ConvertDataTableToList<Banks>(ds.Tables[0]) : Enumerable.Empty<Banks>().ToList();
                    }
                });
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }

        public List<Branch> LoadCacheAllBranchList()
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;
            List<Branch> response = new List<Branch>();
            try
            {
                StoredProcedureReader.Read(StoredProcedureName.SQLConnStringDB, StoredProcedureName.Branch.SPName_SP_BANK_GET_BRANCH, null, (ds) =>
                {
                    if (ds != null && ds.Tables[0].Rows.Count > 0)
                    {
                        response = ds.Tables[0] != null ? NewExtension.ConvertDataTableToList<Branch>(ds.Tables[0]) : Enumerable.Empty<Branch>().ToList();
                    }
                });
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }

        public List<Channel> LoadCacheAllChannelList()
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;
            List<Channel> response = new List<Channel>();
            try
            {
                StoredProcedureReader.Read(StoredProcedureName.SQLConnStringDB, StoredProcedureName.Channel.SPName_SP_BANK_GET_CHANNEL, null, (ds) =>
                {
                    if (ds != null && ds.Tables[0].Rows.Count > 0)
                    {
                        response = ds.Tables[0] != null ? NewExtension.ConvertDataTableToList<Channel>(ds.Tables[0]) : Enumerable.Empty<Channel>().ToList();
                    }
                });
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }

        public List<SubDistrict> LoadCacheAllSubDistrictList()
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;
            List<SubDistrict> response = new List<SubDistrict>();
            try
            {
                StoredProcedureReader.Read(StoredProcedureName.SQLConnStringDB, StoredProcedureName.SubDistrict.SPName_SP_BANK_GET_SUBDISTRICT, null, (ds) =>
                {
                    if (ds != null && ds.Tables[0].Rows.Count > 0)
                    {
                        response = ds.Tables[0] != null ? NewExtension.ConvertDataTableToList<SubDistrict>(ds.Tables[0]) : Enumerable.Empty<SubDistrict>().ToList();
                    }
                });
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }

        public List<District> LoadCacheAllDistrictList()
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;
            List<District> response = new List<District>();
            try
            {
                StoredProcedureReader.Read(StoredProcedureName.SQLConnStringDB, StoredProcedureName.District.SPName_SP_BANK_GET_DISTRICT, null, (ds) =>
                {
                    if (ds != null && ds.Tables[0].Rows.Count > 0)
                    {
                        response = ds.Tables[0] != null ? NewExtension.ConvertDataTableToList<District>(ds.Tables[0]) : Enumerable.Empty<District>().ToList();
                    }
                });
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }

        public List<Province> LoadCacheAllProvinceList()
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;
            List<Province> response = new List<Province>();
            try
            {
                StoredProcedureReader.Read(StoredProcedureName.SQLConnStringDB, StoredProcedureName.Province.SPName_SP_BANK_GET_PROVINCE, null, (ds) =>
                {
                    if (ds != null && ds.Tables[0].Rows.Count > 0)
                    {
                        response = ds.Tables[0] != null ? NewExtension.ConvertDataTableToList<Province>(ds.Tables[0]) : Enumerable.Empty<Province>().ToList();
                    }
                });
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }

        public List<Occupation> LoadCacheAllOccupationList()
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;
            List<Occupation> response = new List<Occupation>();
            try
            {
                StoredProcedureReader.Read(StoredProcedureName.SQLConnStringDB, StoredProcedureName.Occupation.SPName_SP_BANK_GET_OCCUPATION, null, (ds) =>
                {
                    if (ds != null && ds.Tables[0].Rows.Count > 0)
                    {
                        response = ds.Tables[0] != null ? NewExtension.ConvertDataTableToList<Occupation>(ds.Tables[0]) : Enumerable.Empty<Occupation>().ToList();
                    }
                });
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }

        public List<Title> LoadCacheAllTitleList()
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;
            List<Title> response = new List<Title>();
            try
            {
                StoredProcedureReader.Read(StoredProcedureName.SQLConnStringDB, StoredProcedureName.Title.SPName_SP_BANK_GET_TITLE, null, (ds) =>
                {
                    if (ds != null && ds.Tables[0].Rows.Count > 0)
                    {
                        response = ds.Tables[0] != null ? NewExtension.ConvertDataTableToList<Title>(ds.Tables[0]) : Enumerable.Empty<Title>().ToList();
                    }
                });
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }

        public List<TypeFinancial> LoadCacheAllTypeFinancialList()
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;
            List<TypeFinancial> response = new List<TypeFinancial>();
            try
            {
                StoredProcedureReader.Read(StoredProcedureName.SQLConnStringDB, StoredProcedureName.TypeFinancial.SPName_SP_BANK_GET_TYPE_FINANCIAL, null, (ds) =>
                {
                    if (ds != null && ds.Tables[0].Rows.Count > 0)
                    {
                        response = ds.Tables[0] != null ? NewExtension.ConvertDataTableToList<TypeFinancial>(ds.Tables[0]) : Enumerable.Empty<TypeFinancial>().ToList();
                    }
                });
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }

        public List<ManageUser> LoadCacheAllManageUserList()
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;
            List<ManageUser> response = new List<ManageUser>();
            try
            {
                StoredProcedureReader.Read(StoredProcedureName.SQLConnStringDB, StoredProcedureName.ManageUser.SPName_SP_BANK_GET_MANAGE_USER, null, (ds) =>
                {
                    if (ds != null && ds.Tables[0].Rows.Count > 0)
                    {
                        response = ds.Tables[0] != null ? NewExtension.ConvertDataTableToList<ManageUser>(ds.Tables[0]) : Enumerable.Empty<ManageUser>().ToList();
                    }
                });
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }

    }
}