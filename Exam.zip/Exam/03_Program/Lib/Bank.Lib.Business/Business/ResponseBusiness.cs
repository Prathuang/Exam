﻿using Bank.Lib.ConfigurationXML;
using System;
using System.IO;

namespace Bank.Lib.Business
{
    public class ResponseBusiness
    {
        public static Response MakeResponse(Bank.Lib.Business.Cache loadCache, InterfaceResponse ConfigInterface, string messageDesc)
        {
            return MakeResponse(loadCache, ConfigInterface, "", messageDesc);
        }

        public static Response MakeResponse(Bank.Lib.Business.Cache loadCache, InterfaceResponse ConfigInterface, string code, string messageDesc)
        {
            Response response;

            if (loadCache == null)
            {
                string _xmlresponsefile = string.Empty;
                try
                {
                    _xmlresponsefile = System.Web.HttpContext.Current.Server.MapPath("~/App_Data/Response.xml");
                }
                catch { }

                if (string.IsNullOrEmpty(_xmlresponsefile))
                {
                    _xmlresponsefile = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"App_Data\Response.xml");
                }

                if (string.IsNullOrEmpty(code))
                {
                    response = (new XResponse(_xmlresponsefile)).GetResponse(ConfigInterface, messageDesc);
                }
                else
                {
                    response = (new XResponse(_xmlresponsefile)).GetResponse(ConfigInterface, code, messageDesc);
                }
            }
            else
            {
                if (string.IsNullOrEmpty(code))
                {
                    response = loadCache.XResponse.GetResponse(ConfigInterface, messageDesc);
                }
                else
                {
                    response = loadCache.XResponse.GetResponse(ConfigInterface, code, messageDesc);
                }
            }

            return response;
        }
    }
}