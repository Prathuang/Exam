﻿using Bank.Lib.Business.ConnectDB;
using Bank.Lib.CallDB;
using Bank.Lib.ConfigurationXML;
using Bank.Lib.Data;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Bank.Lib.Business
{
    public class CustomerBusiness : InitialData
    {
        public CustomerBusiness(string programName, string guid, string clientIp, string hostIp)
        {
            try
            {
                _messageLog = DoBusiness.GetMessageLog;
                _programName = programName;

                _clientIp = clientIp;
                _hostIp = hostIp;
                _guid = _hostIp.Split('.')[3].PadLeft(3, '0') + "-" + guid;
                System.Configuration.ConfigurationManager.RefreshSection("appSettings");

                InitialWriteLogFile.Initial(programName);
            }
            catch { }
        }

        public CustomerList CheckCustomer(CustomerForSearch request)
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;
            CustomerList response = new CustomerList();
            try
            {
                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("AccountNo", request.AccountNo);
                parameters.Add("CitizenId", request.CitizenId);
                StoredProcedureReader.Read(StoredProcedureName.SQLConnStringDB, StoredProcedureName.Customer.SPName_SP_BANK_GET_CUSTOMER, parameters, (ds) =>
                {
                    if (ds != null && ds.Tables[0].Rows.Count > 0)
                    {
                        messageCode = MessageCode.Success.ToString();
                        response.ObjectList = ds.Tables[0] != null ? NewExtension.ConvertDataTableToList<Customer>(ds.Tables[0]) : Enumerable.Empty<Customer>().ToList();
                    }
                    else
                    {
                        messageCode = MessageCode.DataNotFound.ToString();
                    }
                });
            }
            catch (Exception ex)
            {
                messageCode = MessageCode.Error.ToString();
                messageDesc = ex.Message;
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                Response ResponseXml = Bank.Lib.Business.ResponseBusiness.MakeResponse(loadCache, InterfaceResponse.ResponseService, messageCode, messageDesc);
                response.MessageCode = ResponseXml.MessageCode;
                response.MessageDesc = ResponseXml.MessageDesc;

                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }
        public ResultResponse InsertCustomer(Customer request)
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;

            ResultResponse response = new ResultResponse();
            try
            {
                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("AccountNo", request.AccountNo);
                parameters.Add("TitleCode", request.TitleCode);
                parameters.Add("FirstNameTH", request.FirstNameTH);
                parameters.Add("MiddleNameTH", request.MiddleNameTH);
                parameters.Add("LastNameTH", request.LastNameTH);

                parameters.Add("FirstNameEN", request.FirstNameEN);
                parameters.Add("MiddleNameEN", request.MiddleNameEN);
                parameters.Add("LastNameEN", request.LastNameEN);

                parameters.Add("CitizenId", request.CitizenId);
                parameters.Add("DateOfBirth", request.DateOfBirth);
                parameters.Add("MobileNo", request.MobileNo);
                parameters.Add("EMail", request.EMail);
                parameters.Add("Address", request.Address);

                parameters.Add("Soi", request.Soi);
                parameters.Add("Road", request.Road);
                parameters.Add("SubdistrictCode", request.SubdistrictCode);
                parameters.Add("DistrictCode", request.DistrictCode);
                parameters.Add("ProvinceCode", request.ProvinceCode);

                parameters.Add("ZipCode", request.ZipCode);
                parameters.Add("BranchCode", request.BranchCode);
                parameters.Add("OccupationCode", request.OccupationCode);
                parameters.Add("IsSendCitizenCard", request.IsSendCitizenCard);
                parameters.Add("IsSendImage", request.IsSendImage);

                parameters.Add("CreatedBy", request.CreatedBy);
                parameters.Add("ModifiedBy", request.ModifiedBy);
                parameters.Add("FullNameTH", request.FullNameTH);
                parameters.Add("FullNameEN", request.FullNameEN);

                StoredProcedureReader.ExecStored(StoredProcedureName.SQLConnStringDB, StoredProcedureName.Customer.SPName_SP_BANK_INS_CUSTOMER, parameters, (result) =>
                {
                    if(result.Success)
                    {
                        messageCode = MessageCode.Success.ToString();

                        SaveImageInLocal(request.AccountNo, "FaceImage", request.ImageBase64, request.ImageExtension);
                        SaveImageInLocal(request.AccountNo, "CitizenImage", request.CitizenIdCardImageBase64, request.CitizenIdCardImageExtension);
                    }
                    else
                    {
                        messageCode = MessageCode.Error.ToString();
                        messageDesc = result.Output;
                    }
                });
            }
            catch (Exception ex)
            {
                messageCode = MessageCode.Error.ToString();
                messageDesc = ex.Message;
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                Response ResponseXml = Bank.Lib.Business.ResponseBusiness.MakeResponse(loadCache, InterfaceResponse.ResponseService, messageCode, messageDesc);
                response.MessageCode = ResponseXml.MessageCode;
                response.MessageDesc = ResponseXml.MessageDesc;

                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }

        private void SaveImageInLocal(string accountNo,string typeFileName, string base64String, string extension)
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            try
            {
                if (!Directory.Exists(ConfigMgr.PathImage))
                {
                    Directory.CreateDirectory(ConfigMgr.PathImage);
                }

                string fileName = accountNo + "_" + typeFileName + extension;
                string fullPathFile = Path.Combine(ConfigMgr.PathImage, fileName);
                if (File.Exists(fullPathFile))
                {
                    File.Delete(fullPathFile);
                }
                File.WriteAllBytes(fullPathFile, Convert.FromBase64String(base64String));
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }

        }
    }
}