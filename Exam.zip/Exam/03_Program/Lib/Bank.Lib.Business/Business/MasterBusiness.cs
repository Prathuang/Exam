﻿using Bank.Lib.ConfigurationXML;
using Bank.Lib.Data;
using System;

namespace Bank.Lib.Business
{
    public class MasterBusiness : InitialData
    {
        public MasterBusiness(string programName, string guid, string clientIp, string hostIp)
        {
            try
            {
                _messageLog = DoBusiness.GetMessageLog;
                _programName = programName;

                _clientIp = clientIp;
                _hostIp = hostIp;
                _guid = _hostIp.Split('.')[3].PadLeft(3, '0') + "-" + guid;
                System.Configuration.ConfigurationManager.RefreshSection("appSettings");

                InitialWriteLogFile.Initial(programName);
            }
            catch { }
        }

        public AllMaster GetAllMaster()
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;
            AllMaster response = new AllMaster();
            try
            {
                loadCache = new Bank.Lib.Business.Cache(_programName, _guid, _clientIp, _hostIp);
                if (loadCache != null)
                {
                    messageCode = MessageCode.Success.ToString();
                    response.AllBanks = loadCache.AllBanks;
                    response.AllBranch = loadCache.AllBranch;
                    response.AllChannel = loadCache.AllChannel;
                    response.AllSubDistrict = loadCache.AllSubDistrict;
                    response.AllDistrict = loadCache.AllDistrict;

                    response.AllProvince = loadCache.AllProvince;
                    response.AllOccupation = loadCache.AllOccupation;
                    response.AllTitle = loadCache.AllTitle;
                    response.AllTypeFinancial = loadCache.AllTypeFinancial;
                }
                else
                {
                    messageCode = MessageCode.DataNotFound.ToString();
                }
            }
            catch (Exception ex)
            {
                messageCode = MessageCode.Error.ToString();
                messageDesc = ex.Message;
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                Response ResponseXml = Bank.Lib.Business.ResponseBusiness.MakeResponse(loadCache, InterfaceResponse.ResponseService, messageCode, messageDesc);
                response.MessageCode = ResponseXml.MessageCode;
                response.MessageDesc = ResponseXml.MessageDesc;

                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }

        public BanksList GetBanksList()
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;
            BanksList response = new BanksList();
            try
            {
                loadCache = new Bank.Lib.Business.Cache(_programName, _guid, _clientIp, _hostIp);
                if (loadCache.AllBanks != null && loadCache.AllBanks.Count > 0)
                {
                    messageCode = MessageCode.Success.ToString();
                    response.ObjectList = loadCache.AllBanks;
                }
                else
                {
                    messageCode = MessageCode.DataNotFound.ToString();
                }
            }
            catch (Exception ex)
            {
                messageCode = MessageCode.Error.ToString();
                messageDesc = ex.Message;
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                Response ResponseXml = Bank.Lib.Business.ResponseBusiness.MakeResponse(loadCache, InterfaceResponse.ResponseService, messageCode, messageDesc);
                response.MessageCode = ResponseXml.MessageCode;
                response.MessageDesc = ResponseXml.MessageDesc;

                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }

        public BranchList GetBranchList()
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;
            BranchList response = new BranchList();
            try
            {
                loadCache = new Bank.Lib.Business.Cache(_programName, _guid, _clientIp, _hostIp);
                if (loadCache.AllBranch != null && loadCache.AllBranch.Count > 0)
                {
                    messageCode = MessageCode.Success.ToString();
                    response.ObjectList = loadCache.AllBranch;
                }
                else
                {
                    messageCode = MessageCode.DataNotFound.ToString();
                }
            }
            catch (Exception ex)
            {
                messageCode = MessageCode.Error.ToString();
                messageDesc = ex.Message;
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                Response ResponseXml = Bank.Lib.Business.ResponseBusiness.MakeResponse(loadCache, InterfaceResponse.ResponseService, messageCode, messageDesc);
                response.MessageCode = ResponseXml.MessageCode;
                response.MessageDesc = ResponseXml.MessageDesc;

                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }

        public ChannelList GetChannelList()
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;
            ChannelList response = new ChannelList();
            try
            {
                loadCache = new Bank.Lib.Business.Cache(_programName, _guid, _clientIp, _hostIp);
                if (loadCache.AllChannel != null && loadCache.AllChannel.Count > 0)
                {
                    messageCode = MessageCode.Success.ToString();
                    response.ObjectList = loadCache.AllChannel;
                }
                else
                {
                    messageCode = MessageCode.DataNotFound.ToString();
                }
            }
            catch (Exception ex)
            {
                messageCode = MessageCode.Error.ToString();
                messageDesc = ex.Message;
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                Response ResponseXml = Bank.Lib.Business.ResponseBusiness.MakeResponse(loadCache, InterfaceResponse.ResponseService, messageCode, messageDesc);
                response.MessageCode = ResponseXml.MessageCode;
                response.MessageDesc = ResponseXml.MessageDesc;

                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }

        public SubDistrictList GetSubDistrictList()
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;
            SubDistrictList response = new SubDistrictList();
            try
            {
                loadCache = new Bank.Lib.Business.Cache(_programName, _guid, _clientIp, _hostIp);
                if (loadCache.AllSubDistrict != null && loadCache.AllSubDistrict.Count > 0)
                {
                    messageCode = MessageCode.Success.ToString();
                    response.ObjectList = loadCache.AllSubDistrict;
                }
                else
                {
                    messageCode = MessageCode.DataNotFound.ToString();
                }
            }
            catch (Exception ex)
            {
                messageCode = MessageCode.Error.ToString();
                messageDesc = ex.Message;
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                Response ResponseXml = Bank.Lib.Business.ResponseBusiness.MakeResponse(loadCache, InterfaceResponse.ResponseService, messageCode, messageDesc);
                response.MessageCode = ResponseXml.MessageCode;
                response.MessageDesc = ResponseXml.MessageDesc;

                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }

        public DistrictList GetDistrictList()
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;
            DistrictList response = new DistrictList();
            try
            {
                loadCache = new Bank.Lib.Business.Cache(_programName, _guid, _clientIp, _hostIp);
                if (loadCache.AllDistrict != null && loadCache.AllDistrict.Count > 0)
                {
                    messageCode = MessageCode.Success.ToString();
                    response.ObjectList = loadCache.AllDistrict;
                }
                else
                {
                    messageCode = MessageCode.DataNotFound.ToString();
                }
            }
            catch (Exception ex)
            {
                messageCode = MessageCode.Error.ToString();
                messageDesc = ex.Message;
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                Response ResponseXml = Bank.Lib.Business.ResponseBusiness.MakeResponse(loadCache, InterfaceResponse.ResponseService, messageCode, messageDesc);
                response.MessageCode = ResponseXml.MessageCode;
                response.MessageDesc = ResponseXml.MessageDesc;

                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }

        public ProvinceList GetProvinceList()
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;
            ProvinceList response = new ProvinceList();
            try
            {
                loadCache = new Bank.Lib.Business.Cache(_programName, _guid, _clientIp, _hostIp);
                if (loadCache.AllProvince != null && loadCache.AllProvince.Count > 0)
                {
                    messageCode = MessageCode.Success.ToString();
                    response.ObjectList = loadCache.AllProvince;
                }
                else
                {
                    messageCode = MessageCode.DataNotFound.ToString();
                }
            }
            catch (Exception ex)
            {
                messageCode = MessageCode.Error.ToString();
                messageDesc = ex.Message;
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                Response ResponseXml = Bank.Lib.Business.ResponseBusiness.MakeResponse(loadCache, InterfaceResponse.ResponseService, messageCode, messageDesc);
                response.MessageCode = ResponseXml.MessageCode;
                response.MessageDesc = ResponseXml.MessageDesc;

                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }

        public OccupationList GetOccupationList()
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;
            OccupationList response = new OccupationList();
            try
            {
                loadCache = new Bank.Lib.Business.Cache(_programName, _guid, _clientIp, _hostIp);
                if (loadCache.AllOccupation != null && loadCache.AllOccupation.Count > 0)
                {
                    messageCode = MessageCode.Success.ToString();
                    response.ObjectList = loadCache.AllOccupation;
                }
                else
                {
                    messageCode = MessageCode.DataNotFound.ToString();
                }
            }
            catch (Exception ex)
            {
                messageCode = MessageCode.Error.ToString();
                messageDesc = ex.Message;
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                Response ResponseXml = Bank.Lib.Business.ResponseBusiness.MakeResponse(loadCache, InterfaceResponse.ResponseService, messageCode, messageDesc);
                response.MessageCode = ResponseXml.MessageCode;
                response.MessageDesc = ResponseXml.MessageDesc;

                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }

        public TitleList GetTitleList()
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;
            TitleList response = new TitleList();
            try
            {
                loadCache = new Bank.Lib.Business.Cache(_programName, _guid, _clientIp, _hostIp);
                if (loadCache.AllTitle != null && loadCache.AllTitle.Count > 0)
                {
                    messageCode = MessageCode.Success.ToString();
                    response.ObjectList = loadCache.AllTitle;
                }
                else
                {
                    messageCode = MessageCode.DataNotFound.ToString();
                }
            }
            catch (Exception ex)
            {
                messageCode = MessageCode.Error.ToString();
                messageDesc = ex.Message;
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }

        public TypeFinancialList GetTypeFinancialList()
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;
            TypeFinancialList response = new TypeFinancialList();
            try
            {
                loadCache = new Bank.Lib.Business.Cache(_programName, _guid, _clientIp, _hostIp);
                if (loadCache.AllTypeFinancial != null && loadCache.AllTypeFinancial.Count > 0)
                {
                    messageCode = MessageCode.Success.ToString();
                    response.ObjectList = loadCache.AllTypeFinancial;
                }
                else
                {
                    messageCode = MessageCode.DataNotFound.ToString();
                }
            }
            catch (Exception ex)
            {
                messageCode = MessageCode.Error.ToString();
                messageDesc = ex.Message;
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                Response ResponseXml = Bank.Lib.Business.ResponseBusiness.MakeResponse(loadCache, InterfaceResponse.ResponseService, messageCode, messageDesc);
                response.MessageCode = ResponseXml.MessageCode;
                response.MessageDesc = ResponseXml.MessageDesc;

                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }
    }
}