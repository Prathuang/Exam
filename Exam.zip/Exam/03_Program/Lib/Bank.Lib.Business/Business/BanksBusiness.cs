﻿using Bank.Lib.Business.ConnectDB;
using Bank.Lib.CallDB;
using Bank.Lib.ConfigurationXML;
using Bank.Lib.Data;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Bank.Lib.Business
{
    public class BanksBusiness : InitialData
    {
        public BanksBusiness(string programName, string guid, string clientIp, string hostIp)
        {
            try
            {
                _messageLog = DoBusiness.GetMessageLog; 
                _programName = programName;

                _clientIp = clientIp;
                _hostIp = hostIp;
                _guid = _hostIp.Split('.')[3].PadLeft(3, '0') + "-" + guid;
                System.Configuration.ConfigurationManager.RefreshSection("appSettings");
                
                InitialWriteLogFile.Initial(programName);
            }
            catch { }
        }

        public string GetIBANNumber()
        {
            string response = string.Empty;
            try
            {
                bool isSuccess = false;
                string errorMessage = string.Empty;
                Bank.Lib.Business.Cache loadCache = new Bank.Lib.Business.Cache(_programName, _guid, _clientIp, _hostIp);
                Bank.Lib.CallRestfulAPI.CallRestfulAPI process = new Bank.Lib.CallRestfulAPI.CallRestfulAPI(loadCache.ApiConfiguration.ApiConfig.Service["CallIBANNumber"].Url, loadCache.ApiConfiguration.ApiConfig.Service["CallIBANNumber"].Timeout);
                response = process.GetStringAPI( ref isSuccess, ref errorMessage);
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger("BankBusiness").Error("Insert => Error Message : " + ex.Message);
            }

            return response;
        }

        public ResultResponse InsertFinancialTransaction(FinancialTransaction request)
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;

            ResultResponse response = new ResultResponse();
            try
            {
                decimal FeeAmount = 0;
                decimal Amount = 0;
                if (request.TypeFinancialCode.Equals("DEPOSIT"))
                {
                    FeeAmount = (ConfigMgr.FeeForDeposit * request.Amount) / 100;
                    Amount = request.Amount - FeeAmount;
                }
                else
                {
                    Amount = request.Amount;
                }

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("TypeFinancialCode", request.TypeFinancialCode);
                parameters.Add("ChannelCode", request.ChannelCode);
                parameters.Add("BranchCode", request.BranchCode);
                parameters.Add("AccountNo", request.AccountNo);
                parameters.Add("TypeCash", request.TypeCash);

                parameters.Add("FeeAmount", FeeAmount);
                parameters.Add("Amount", Amount);
                parameters.Add("RelatedBankCode", request.RelatedBankCode);

                parameters.Add("RelatedAccountNo", request.RelatedAccountNo);
                parameters.Add("MemoMessage", request.MemoMessage);
                parameters.Add("Description", request.Description);
                parameters.Add("TransactionBy", request.TransactionBy);
                parameters.Add("IsSameBank", request.IsSameBank);

                StoredProcedureReader.ExecStored(StoredProcedureName.SQLConnStringDB, StoredProcedureName.FinancialTransaction.SPName_SP_BANK_SET_BALANCE_TRANSACTION, parameters, (result) =>
                {
                    if (result.Success)
                    {
                        messageCode = MessageCode.Success.ToString();
                    }
                    else
                    {
                        messageCode = MessageCode.Error.ToString();
                        messageDesc = result.Output;
                    }
                });
            }
            catch (Exception ex)
            {
                messageCode = MessageCode.Error.ToString();
                messageDesc = ex.Message;
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                Response ResponseXml = Bank.Lib.Business.ResponseBusiness.MakeResponse(loadCache, InterfaceResponse.ResponseService, messageCode, messageDesc);
                response.MessageCode = ResponseXml.MessageCode;
                response.MessageDesc = ResponseXml.MessageDesc;

                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }

        public BalanceDataList GetBalanceData(BalanceData request)
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;
            BalanceDataList response = new BalanceDataList();
            try
            {
                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("AccountNo", request.AccountNo);
                StoredProcedureReader.Read(StoredProcedureName.SQLConnStringDB, StoredProcedureName.Balance.SPName_SP_BANK_GET_BALANCE, parameters, (ds) =>
                {
                    if (ds != null && ds.Tables[0].Rows.Count > 0)
                    {
                        messageCode = MessageCode.Success.ToString();
                        response.ObjectList = ds.Tables[0] != null ? NewExtension.ConvertDataTableToList<BalanceData>(ds.Tables[0]) : Enumerable.Empty<BalanceData>().ToList();
                    }
                    else
                    {
                        messageCode = MessageCode.DataNotFound.ToString();
                    }
                });
            }
            catch (Exception ex)
            {
                messageCode = MessageCode.Error.ToString();
                messageDesc = ex.Message;
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                Response ResponseXml = Bank.Lib.Business.ResponseBusiness.MakeResponse(loadCache, InterfaceResponse.ResponseService, messageCode, messageDesc);
                response.MessageCode = ResponseXml.MessageCode;
                response.MessageDesc = ResponseXml.MessageDesc;

                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }
    }
}