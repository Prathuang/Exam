﻿using System;
using System.Configuration;

namespace Bank.Lib.Business
{
    public class ConfigMgr
    {
        public static decimal FeeForDeposit
        {
            get { return Convert.ToDecimal(ConfigurationManager.AppSettings["FeeForDeposit"]); }
        }

        public static string PathImage
        {
            get { return ConfigurationManager.AppSettings["PathImage"].ToString(); }
        }
    }
}