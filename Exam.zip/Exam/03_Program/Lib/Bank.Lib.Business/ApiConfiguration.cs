﻿using System;
using System.Xml.Linq;

namespace Bank.Lib.Business
{
    public class ApiConfiguration
    {
        #region Properties
        public ApiConfig ApiConfig { get; private set; }
        #endregion

        #region Constructors
        public ApiConfiguration(String uri)
        {
            XDocument xDoc = XDocument.Load(uri);
            ApiConfig = new ApiConfig(xDoc.Descendants("Services"));
        }
        #endregion
    }
}