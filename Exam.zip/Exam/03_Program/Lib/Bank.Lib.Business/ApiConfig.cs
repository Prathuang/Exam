﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace Bank.Lib.Business
{
    public class ApiConfig
    {
        public ApiConfigCommandCollection Service { get; private set; }

        internal ApiConfig(IEnumerable<XElement> xelement)
        {
            var priv = from obj in xelement
                       select new
                       {
                           Service = obj.Elements("Service")
                       };

            var anonymous = priv.First();
            this.Service = new ApiConfigCommandCollection(anonymous.Service);
        }
    }

    public class ApiConfigCommand
    {
        public string Name { get; private set; }
        public string Url { get; private set; }
        public int Timeout { get; private set; }

        internal ApiConfigCommand(string name, string url, int timeout)
        {
            this.Name = name;
            this.Url = url;
            this.Timeout = timeout;
        }
    }

    public class ApiConfigCommandCollection
    {
        private Dictionary<string, ApiConfigCommand> _command;
        public ApiConfigCommand this[string key]
        {
            get
            {
                return _command[key];
            }
        }

        internal ApiConfigCommandCollection(IEnumerable<XElement> xelement)
        {
            var anonymous = from e in xelement
                            select new
                            {
                                Name = e.Attribute("Name").Value,
                                Url = e.Attribute("Url").Value,
                                Timeout = Int32.Parse(e.Attribute("Timeout").Value)
                            };

            _command = new Dictionary<string, ApiConfigCommand>(anonymous.Count());
            foreach (var a in anonymous)
            {
                _command.Add(a.Name, new ApiConfigCommand(a.Name, a.Url, a.Timeout));
            }
        }
    }
}