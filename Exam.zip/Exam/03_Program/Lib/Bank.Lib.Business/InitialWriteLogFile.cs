﻿using System;

namespace Bank.Lib.Business
{
    public class InitialWriteLogFile
    {
        public static void Initial(string programName)
        {
            if ((!System.Configuration.ConfigurationManager.AppSettings["LogFilesPath"].EndsWith(@"\\")))
                System.Configuration.ConfigurationManager.AppSettings["LogFilesPath"] = System.Configuration.ConfigurationManager.AppSettings["LogFilesPath"] + @"\\";

            log4net.GlobalContext.Properties["LogFilesPath"] = System.Configuration.ConfigurationManager.AppSettings["LogFilesPath"];
            log4net.GlobalContext.Properties["ApplicationCode"] = programName;// "BankService";
            log4net.GlobalContext.Properties["ServerName"] = Environment.MachineName;
            log4net.Config.XmlConfigurator.ConfigureAndWatch(new System.IO.FileInfo(System.Web.HttpContext.Current.Server.MapPath("~/log4net.config")));
        }
    }
}