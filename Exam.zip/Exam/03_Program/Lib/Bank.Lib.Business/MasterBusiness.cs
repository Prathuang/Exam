﻿using Bank.Lib.Data;
using System;
using System.Collections.Generic;

namespace Bank.Lib.Business
{
    public class MasterBusiness/// : InitialData
    {
        public string _messageLog = string.Empty;

        public string _guid;
        public string _clientIp = string.Empty;
        public string _hostIp = string.Empty;

        public string _methodName = string.Empty;
        public string _programName = string.Empty;
        public MasterBusiness(string programName, string guid, string clientIp, string hostIp)
        {
            try
            {
                _messageLog = DoBusiness.GetMessageLog;
                _programName = programName;

                _clientIp = clientIp;
                _hostIp = hostIp;
                _guid = _hostIp.Split('.')[3].PadLeft(3, '0') + "-" + guid;
                System.Configuration.ConfigurationManager.RefreshSection("appSettings");

                InitialWriteLogFile.Initial(programName);
            }
            catch { }
        }

        public List<Banks> GetBanksList()
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;
            List<Banks> response = new List<Banks>();
            try
            {
                Bank.Lib.Business.Cache loadCache = new Bank.Lib.Business.Cache(_programName, _guid, _clientIp, _hostIp);
                response = loadCache.AllBanks;
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }

        public List<Branch> GetBranchList()
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;
            List<Branch> response = new List<Branch>();
            try
            {
                Bank.Lib.Business.Cache loadCache = new Bank.Lib.Business.Cache(_programName, _guid, _clientIp, _hostIp);
                response = loadCache.AllBranch;
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }

        public List<Channel> GetChannelList()
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;
            List<Channel> response = new List<Channel>();
            try
            {
                Bank.Lib.Business.Cache loadCache = new Bank.Lib.Business.Cache(_programName, _guid, _clientIp, _hostIp);
                response = loadCache.AllChannel;
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }

        public List<SubDistrict> GetSubDistrictList()
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;
            List<SubDistrict> response = new List<SubDistrict>();
            try
            {
                Bank.Lib.Business.Cache loadCache = new Bank.Lib.Business.Cache(_programName, _guid, _clientIp, _hostIp);
                response = loadCache.AllSubDistrict;
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }

        public List<District> GetDistrictList()
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;
            List<District> response = new List<District>();
            try
            {
                Bank.Lib.Business.Cache loadCache = new Bank.Lib.Business.Cache(_programName, _guid, _clientIp, _hostIp);
                response = loadCache.AllDistrict;
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }

        public List<Province> GetProvinceList()
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;
            List<Province> response = new List<Province>();
            try
            {
                Bank.Lib.Business.Cache loadCache = new Bank.Lib.Business.Cache(_programName, _guid, _clientIp, _hostIp);
                response = loadCache.AllProvince;
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }

        public List<Occupation> GetOccupationList()
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;
            List<Occupation> response = new List<Occupation>();
            try
            {
                Bank.Lib.Business.Cache loadCache = new Bank.Lib.Business.Cache(_programName, _guid, _clientIp, _hostIp);
                response = loadCache.AllOccupation;
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }

        public List<Title> GetTitleList()
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;
            List<Title> response = new List<Title>();
            try
            {
                Bank.Lib.Business.Cache loadCache = new Bank.Lib.Business.Cache(_programName, _guid, _clientIp, _hostIp);
                response = loadCache.AllTitle;
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }

        public List<TypeFinancial> GetTypeFinancialList()
        {
            _methodName = System.Reflection.MethodBase.GetCurrentMethod().Name;
            log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("Start {0}", _methodName));
            DateTime StartTime = DateTime.Now;
            List<TypeFinancial> response = new List<TypeFinancial>();
            try
            {
                Bank.Lib.Business.Cache loadCache = new Bank.Lib.Business.Cache(_programName, _guid, _clientIp, _hostIp);
                response = loadCache.AllTypeFinancial;
            }
            catch (Exception ex)
            {
                log4net.LogManager.GetLogger(_programName).ErrorFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("{0} => Error Message : {1}", _methodName, ex.Message));
            }
            finally
            {
                log4net.LogManager.GetLogger(_programName).InfoFormat(_messageLog, _guid, _clientIp, _hostIp, _methodName, string.Format("End {0} => Total Process: {1} ms.", _methodName, ((TimeSpan)(DateTime.Now - StartTime)).TotalMilliseconds));
            }

            return response;
        }

        //public static ResultStringValue Insert(Customer request)
        //{
        //    ResultStringValue response = new ResultStringValue();
        //    try
        //    {
        //        Dictionary<string, object> parameters = new Dictionary<string, object>();
        //        parameters.Add("AccountNo", request.AccountNo);
        //        parameters.Add("TitleCode", request.TitleCode);
        //        parameters.Add("FirstNameTH", request.FirstNameTH);
        //        parameters.Add("MiddleNameTH", request.MiddleNameTH);
        //        parameters.Add("LastNameTH", request.LastNameTH);

        //        //parameters.Add("TitleEN", request.TitleEN);
        //        parameters.Add("FirstNameEN", request.FirstNameEN);
        //        parameters.Add("MiddleNameEN", request.MiddleNameEN);
        //        parameters.Add("LastNameEN", request.LastNameEN);

        //        parameters.Add("CitizenId", request.CitizenId);
        //        parameters.Add("DateOfBirth", request.DateOfBirth);
        //        parameters.Add("MobileNo", request.MobileNo);
        //        parameters.Add("EMail", request.EMail);
        //        parameters.Add("Address", request.Address);

        //        parameters.Add("Soi", request.Soi);
        //        parameters.Add("Road", request.Road);
        //        parameters.Add("SubdistrictCode", request.SubdistrictCode);
        //        parameters.Add("DistrictCode", request.DistrictCode);
        //        parameters.Add("ProvinceCode", request.ProvinceCode);

        //        parameters.Add("ZipCode", request.ZipCode);
        //        parameters.Add("BranchCode", request.BranchCode);
        //        parameters.Add("OccupationCode", request.OccupationCode);
        //        parameters.Add("IsSendCitizenCard", request.IsSendCitizenCard);
        //        parameters.Add("IsSendImage", request.IsSendImage);

        //        StoredProcedureReader.ExecStored(StoredProcedureName.SQLConnStringDB, "", parameters, (success) =>
        //        {
        //            response.Success = success;
        //        });
        //    }
        //    catch (Exception ex)
        //    {
        //        response.Success = false;
        //        response.ErrorMessage = ex.Message;
        //        //InitialWriteLogFile.Initial();
        //        log4net.LogManager.GetLogger("MasterBusiness").Debug("Insert => Error Message : " + ex.Message);
        //    }

        //    return response;
        //}

        //public static ResultStringValue Update(Customer request)
        //{
        //    ResultStringValue response = new ResultStringValue();
        //    try
        //    {
        //        Dictionary<string, object> parameters = new Dictionary<string, object>();
        //        parameters.Add("AccountNo", request.AccountNo);
        //        //parameters.Add("AccountName", request.AccountName);
        //        parameters.Add("CitizenId", request.CitizenId);
        //        parameters.Add("BranchCode", request.BranchCode);

        //        StoredProcedureReader.ExecStored(StoredProcedureName.SQLConnStringDB, "", parameters, (success) =>
        //        {
        //            response.Success = success;
        //        });
        //    }
        //    catch (Exception ex)
        //    {
        //        response.Success = false;
        //        response.ErrorMessage = ex.Message;
        //        //InitialWriteLogFile.Initial();
        //        log4net.LogManager.GetLogger("MasterBusiness").Debug("Update => Error Message : " + ex.Message);
        //    }

        //    return response;
        //}

        //public static ResultStringValue Delete(Customer request)
        //{
        //    ResultStringValue response = new ResultStringValue();
        //    try
        //    {
        //        Dictionary<string, object> parameters = new Dictionary<string, object>();
        //        parameters.Add("AccountNo", request.AccountNo);
        //        //parameters.Add("AccountName", request.AccountName);
        //        parameters.Add("CitizenId", request.CitizenId);
        //        parameters.Add("BranchCode", request.BranchCode);

        //        StoredProcedureReader.ExecStored(StoredProcedureName.SQLConnStringDB, "", parameters, (success) =>
        //        {
        //            response.Success = success;
        //        });
        //    }
        //    catch (Exception ex)
        //    {
        //        response.Success = false;
        //        response.ErrorMessage = ex.Message;
        //        //InitialWriteLogFile.Initial();
        //        log4net.LogManager.GetLogger("MasterBusiness").Debug("Update => Error Message : " + ex.Message);
        //    }

        //    return response;
        //}

    }
}