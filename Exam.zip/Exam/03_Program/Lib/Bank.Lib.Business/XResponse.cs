﻿using System;
using System.Linq;
using System.Xml.Linq;

namespace Bank.Lib.Business
{
    public class XResponse
    {
        #region Fields
        private XDocument _xDoc;
        #endregion

        #region Constructors
        public XResponse(String uri)
        {
            _xDoc = XDocument.Load(uri);
        }
        #endregion

        #region Methods
        public virtual Response GetResponse(InterfaceResponse inf, String messageDesc)
        {
            var anonymous = from e in _xDoc.Element("Response").Elements(inf.ToString()).Elements("Message").Elements("Internal")
                            where e.Attribute("messageDesc").Value.Equals(messageDesc)
                            select new
                            {
                                MessageCode = e.Parent.Attribute("messageCode").Value,
                                MessageDesc = string.Format(e.Parent.Attribute("messageDesc").Value, messageDesc)
                            };

            if (anonymous.Count().Equals(0))
            {
                anonymous = from e in _xDoc.Element("Response").Elements(inf.ToString()).Elements("Default")
                            select new
                            {
                                MessageCode = e.Attribute("messageCode").Value,
                                MessageDesc = string.Format(e.Attribute("messageDesc").Value, messageDesc)
                            };
            }

            var element = anonymous.First();
            return new Response(inf, element.MessageCode, element.MessageDesc);
        }

        public virtual Response GetResponse(InterfaceResponse inf, String code, String messageDesc)
        {
            var anonymous = from e in _xDoc.Element("Response").Elements(inf.ToString()).Elements("Message").Elements("Internal")
                            where e.Attribute("code").Value.Equals(code)
                            select new
                            {
                                Code = e.Parent.Attribute("code").Value,
                                MessageCode = e.Parent.Attribute("messageCode").Value,
                                MessageDesc = string.Format(e.Parent.Attribute("messageDesc").Value, messageDesc)
                            };

            if (anonymous.Count().Equals(0))
            {
                anonymous = from e in _xDoc.Element("Response").Elements(inf.ToString()).Elements("Default")
                            select new
                            {
                                Code = e.Attribute("code").Value,
                                MessageCode = e.Attribute("messageCode").Value,
                                MessageDesc = string.Format(e.Attribute("messageDesc").Value, messageDesc)
                            };
            }

            var element = anonymous.First();
            return new Response(inf, element.Code, element.MessageCode, element.MessageDesc);
        }

        #endregion
    }
}