﻿namespace Bank.UC.ucManageCustomer
{
    partial class ucManageCustomer
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucManageCustomer));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btnImage = new System.Windows.Forms.Button();
            this.btnCitizenIdCard = new System.Windows.Forms.Button();
            this.txtAccountNo = new System.Windows.Forms.TextBox();
            this.txtFirstNameTH = new System.Windows.Forms.TextBox();
            this.txtMiddleNameTH = new System.Windows.Forms.TextBox();
            this.txtLastNameTH = new System.Windows.Forms.TextBox();
            this.txtEMail = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtZipCode = new System.Windows.Forms.TextBox();
            this.cboTitleTH = new System.Windows.Forms.ComboBox();
            this.txtLastNameEN = new System.Windows.Forms.TextBox();
            this.txtMiddleNameEN = new System.Windows.Forms.TextBox();
            this.txtFirstNameEN = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txtCitizenId = new System.Windows.Forms.MaskedTextBox();
            this.txtMobileNo = new System.Windows.Forms.MaskedTextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtTitleEN = new System.Windows.Forms.TextBox();
            this.dtpDateOfBirth = new System.Windows.Forms.DateTimePicker();
            this.cboSubdistrict = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.cboDistrict = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.cboProvince = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtSoi = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtRoad = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButtonAdd = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonExit = new System.Windows.Forms.ToolStripButton();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.pbCitizenIdCard = new System.Windows.Forms.PictureBox();
            this.pbIamge = new System.Windows.Forms.PictureBox();
            this.cboOccupation = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCitizenIdCard)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbIamge)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(290, 153);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "First Name (TH)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(290, 233);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 18);
            this.label2.TabIndex = 2;
            this.label2.Text = "Last Name (TH)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(290, 273);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 18);
            this.label3.TabIndex = 3;
            this.label3.Text = "Citizen Id";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(290, 393);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 18);
            this.label4.TabIndex = 5;
            this.label4.Text = "E-mail";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(290, 353);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 18);
            this.label5.TabIndex = 6;
            this.label5.Text = "Mobile No";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(290, 113);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 18);
            this.label6.TabIndex = 7;
            this.label6.Text = "Title (TH)";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(290, 193);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(129, 18);
            this.label7.TabIndex = 8;
            this.label7.Text = "Middle Name (TH)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(290, 313);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(93, 18);
            this.label8.TabIndex = 9;
            this.label8.Text = "Date Of Birth";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(290, 433);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 18);
            this.label9.TabIndex = 10;
            this.label9.Text = "Address";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(650, 598);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(68, 18);
            this.label10.TabIndex = 11;
            this.label10.Text = "Zip Code";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(290, 73);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(86, 18);
            this.label11.TabIndex = 12;
            this.label11.Text = "Account No";
            // 
            // btnImage
            // 
            this.btnImage.Location = new System.Drawing.Point(20, 290);
            this.btnImage.Name = "btnImage";
            this.btnImage.Size = new System.Drawing.Size(180, 32);
            this.btnImage.TabIndex = 22;
            this.btnImage.Text = "Image";
            this.btnImage.UseVisualStyleBackColor = true;
            this.btnImage.Click += new System.EventHandler(this.btnImage_Click);
            // 
            // btnCitizenIdCard
            // 
            this.btnCitizenIdCard.Location = new System.Drawing.Point(20, 505);
            this.btnCitizenIdCard.Name = "btnCitizenIdCard";
            this.btnCitizenIdCard.Size = new System.Drawing.Size(258, 32);
            this.btnCitizenIdCard.TabIndex = 23;
            this.btnCitizenIdCard.Text = "Citizen Id Card";
            this.btnCitizenIdCard.UseVisualStyleBackColor = true;
            this.btnCitizenIdCard.Click += new System.EventHandler(this.btnCitizenIdCard_Click);
            // 
            // txtAccountNo
            // 
            this.txtAccountNo.Location = new System.Drawing.Point(430, 70);
            this.txtAccountNo.MaxLength = 30;
            this.txtAccountNo.Name = "txtAccountNo";
            this.txtAccountNo.Size = new System.Drawing.Size(200, 24);
            this.txtAccountNo.TabIndex = 0;
            this.txtAccountNo.Enter += new System.EventHandler(this.txtAccountNo_Enter);
            // 
            // txtFirstNameTH
            // 
            this.txtFirstNameTH.Location = new System.Drawing.Point(430, 150);
            this.txtFirstNameTH.MaxLength = 200;
            this.txtFirstNameTH.Name = "txtFirstNameTH";
            this.txtFirstNameTH.Size = new System.Drawing.Size(200, 24);
            this.txtFirstNameTH.TabIndex = 2;
            this.txtFirstNameTH.Enter += new System.EventHandler(this.txtFirstNameTH_Enter);
            // 
            // txtMiddleNameTH
            // 
            this.txtMiddleNameTH.Location = new System.Drawing.Point(430, 190);
            this.txtMiddleNameTH.MaxLength = 200;
            this.txtMiddleNameTH.Name = "txtMiddleNameTH";
            this.txtMiddleNameTH.Size = new System.Drawing.Size(200, 24);
            this.txtMiddleNameTH.TabIndex = 4;
            this.txtMiddleNameTH.Enter += new System.EventHandler(this.txtMiddleNameTH_Enter);
            // 
            // txtLastNameTH
            // 
            this.txtLastNameTH.Location = new System.Drawing.Point(430, 230);
            this.txtLastNameTH.MaxLength = 200;
            this.txtLastNameTH.Name = "txtLastNameTH";
            this.txtLastNameTH.Size = new System.Drawing.Size(200, 24);
            this.txtLastNameTH.TabIndex = 6;
            this.txtLastNameTH.Enter += new System.EventHandler(this.txtLastNameTH_Enter);
            // 
            // txtEMail
            // 
            this.txtEMail.Location = new System.Drawing.Point(430, 390);
            this.txtEMail.MaxLength = 100;
            this.txtEMail.Name = "txtEMail";
            this.txtEMail.Size = new System.Drawing.Size(560, 24);
            this.txtEMail.TabIndex = 12;
            this.txtEMail.Enter += new System.EventHandler(this.txtEMail_Enter);
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(430, 430);
            this.txtAddress.MaxLength = 300;
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(560, 70);
            this.txtAddress.TabIndex = 13;
            this.txtAddress.Enter += new System.EventHandler(this.txtAddress_Enter);
            // 
            // txtZipCode
            // 
            this.txtZipCode.Location = new System.Drawing.Point(790, 595);
            this.txtZipCode.MaxLength = 5;
            this.txtZipCode.Name = "txtZipCode";
            this.txtZipCode.Size = new System.Drawing.Size(200, 24);
            this.txtZipCode.TabIndex = 19;
            this.txtZipCode.Enter += new System.EventHandler(this.txtZipCode_Enter);
            // 
            // cboTitleTH
            // 
            this.cboTitleTH.DisplayMember = "TitleNameTH";
            this.cboTitleTH.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTitleTH.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cboTitleTH.FormattingEnabled = true;
            this.cboTitleTH.Location = new System.Drawing.Point(430, 110);
            this.cboTitleTH.Name = "cboTitleTH";
            this.cboTitleTH.Size = new System.Drawing.Size(200, 26);
            this.cboTitleTH.TabIndex = 1;
            this.cboTitleTH.SelectedIndexChanged += new System.EventHandler(this.cboTitleTH_SelectedIndexChanged);
            this.cboTitleTH.Enter += new System.EventHandler(this.cboTitleTH_Enter);
            // 
            // txtLastNameEN
            // 
            this.txtLastNameEN.Location = new System.Drawing.Point(790, 230);
            this.txtLastNameEN.MaxLength = 200;
            this.txtLastNameEN.Name = "txtLastNameEN";
            this.txtLastNameEN.Size = new System.Drawing.Size(200, 24);
            this.txtLastNameEN.TabIndex = 7;
            this.txtLastNameEN.Enter += new System.EventHandler(this.txtLastNameEN_Enter);
            // 
            // txtMiddleNameEN
            // 
            this.txtMiddleNameEN.Location = new System.Drawing.Point(790, 190);
            this.txtMiddleNameEN.MaxLength = 200;
            this.txtMiddleNameEN.Name = "txtMiddleNameEN";
            this.txtMiddleNameEN.Size = new System.Drawing.Size(200, 24);
            this.txtMiddleNameEN.TabIndex = 5;
            this.txtMiddleNameEN.Enter += new System.EventHandler(this.txtMiddleNameEN_Enter);
            // 
            // txtFirstNameEN
            // 
            this.txtFirstNameEN.Location = new System.Drawing.Point(790, 150);
            this.txtFirstNameEN.MaxLength = 200;
            this.txtFirstNameEN.Name = "txtFirstNameEN";
            this.txtFirstNameEN.Size = new System.Drawing.Size(200, 24);
            this.txtFirstNameEN.TabIndex = 3;
            this.txtFirstNameEN.Enter += new System.EventHandler(this.txtFirstNameEN_Enter);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(650, 193);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(130, 18);
            this.label12.TabIndex = 31;
            this.label12.Text = "Middle Name (EN)";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(650, 233);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(115, 18);
            this.label13.TabIndex = 30;
            this.label13.Text = "Last Name (EN)";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(650, 153);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(116, 18);
            this.label14.TabIndex = 29;
            this.label14.Text = "First Name (EN)";
            // 
            // txtCitizenId
            // 
            this.txtCitizenId.Location = new System.Drawing.Point(430, 270);
            this.txtCitizenId.Mask = "0-0000-00000-00-0";
            this.txtCitizenId.Name = "txtCitizenId";
            this.txtCitizenId.Size = new System.Drawing.Size(200, 24);
            this.txtCitizenId.TabIndex = 8;
            this.txtCitizenId.Enter += new System.EventHandler(this.txtCitizenId_Enter);
            // 
            // txtMobileNo
            // 
            this.txtMobileNo.Location = new System.Drawing.Point(430, 350);
            this.txtMobileNo.Mask = "000-0000-000";
            this.txtMobileNo.Name = "txtMobileNo";
            this.txtMobileNo.Size = new System.Drawing.Size(200, 24);
            this.txtMobileNo.TabIndex = 11;
            this.txtMobileNo.Enter += new System.EventHandler(this.txtMobileNo_Enter);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(650, 113);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(70, 18);
            this.label15.TabIndex = 37;
            this.label15.Text = "Title (EN)";
            // 
            // txtTitleEN
            // 
            this.txtTitleEN.Location = new System.Drawing.Point(790, 110);
            this.txtTitleEN.Name = "txtTitleEN";
            this.txtTitleEN.ReadOnly = true;
            this.txtTitleEN.Size = new System.Drawing.Size(200, 24);
            this.txtTitleEN.TabIndex = 38;
            this.txtTitleEN.TabStop = false;
            // 
            // dtpDateOfBirth
            // 
            this.dtpDateOfBirth.CustomFormat = "";
            this.dtpDateOfBirth.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDateOfBirth.Location = new System.Drawing.Point(430, 310);
            this.dtpDateOfBirth.Name = "dtpDateOfBirth";
            this.dtpDateOfBirth.Size = new System.Drawing.Size(200, 24);
            this.dtpDateOfBirth.TabIndex = 10;
            this.dtpDateOfBirth.Enter += new System.EventHandler(this.dtpDateOfBirth_Enter);
            // 
            // cboSubdistrict
            // 
            this.cboSubdistrict.DisplayMember = "SubDistrictNameEN";
            this.cboSubdistrict.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSubdistrict.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cboSubdistrict.FormattingEnabled = true;
            this.cboSubdistrict.Location = new System.Drawing.Point(430, 555);
            this.cboSubdistrict.Name = "cboSubdistrict";
            this.cboSubdistrict.Size = new System.Drawing.Size(200, 26);
            this.cboSubdistrict.TabIndex = 16;
            this.cboSubdistrict.SelectedIndexChanged += new System.EventHandler(this.cboSubdistrict_SelectedIndexChanged);
            this.cboSubdistrict.Enter += new System.EventHandler(this.cboSubdistrict_Enter);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(290, 558);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(77, 18);
            this.label16.TabIndex = 40;
            this.label16.Text = "Subdistrict";
            // 
            // cboDistrict
            // 
            this.cboDistrict.DisplayMember = "DistrictNameEN";
            this.cboDistrict.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboDistrict.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cboDistrict.FormattingEnabled = true;
            this.cboDistrict.Location = new System.Drawing.Point(790, 556);
            this.cboDistrict.Name = "cboDistrict";
            this.cboDistrict.Size = new System.Drawing.Size(200, 26);
            this.cboDistrict.TabIndex = 17;
            this.cboDistrict.SelectedIndexChanged += new System.EventHandler(this.cboDistrict_SelectedIndexChanged);
            this.cboDistrict.Enter += new System.EventHandler(this.cboDistrict_Enter);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(650, 558);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(54, 18);
            this.label17.TabIndex = 42;
            this.label17.Text = "District";
            // 
            // cboProvince
            // 
            this.cboProvince.DisplayMember = "ProvinceNameEN";
            this.cboProvince.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboProvince.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cboProvince.FormattingEnabled = true;
            this.cboProvince.Location = new System.Drawing.Point(430, 595);
            this.cboProvince.Name = "cboProvince";
            this.cboProvince.Size = new System.Drawing.Size(200, 26);
            this.cboProvince.TabIndex = 18;
            this.cboProvince.SelectedIndexChanged += new System.EventHandler(this.cboProvince_SelectedIndexChanged);
            this.cboProvince.Enter += new System.EventHandler(this.cboProvince_Enter);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(290, 598);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(66, 18);
            this.label18.TabIndex = 44;
            this.label18.Text = "Province";
            // 
            // txtSoi
            // 
            this.txtSoi.Location = new System.Drawing.Point(430, 515);
            this.txtSoi.MaxLength = 100;
            this.txtSoi.Name = "txtSoi";
            this.txtSoi.Size = new System.Drawing.Size(200, 24);
            this.txtSoi.TabIndex = 14;
            this.txtSoi.Enter += new System.EventHandler(this.txtSoi_Enter);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(290, 518);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(73, 18);
            this.label19.TabIndex = 46;
            this.label19.Text = "Soi / Trok";
            // 
            // txtRoad
            // 
            this.txtRoad.Location = new System.Drawing.Point(790, 515);
            this.txtRoad.MaxLength = 100;
            this.txtRoad.Name = "txtRoad";
            this.txtRoad.Size = new System.Drawing.Size(200, 24);
            this.txtRoad.TabIndex = 15;
            this.txtRoad.Enter += new System.EventHandler(this.txtRoad_Enter);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(650, 518);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(44, 18);
            this.label20.TabIndex = 48;
            this.label20.Text = "Road";
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButtonAdd,
            this.toolStripSeparator2,
            this.toolStripButtonExit});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1008, 25);
            this.toolStrip1.TabIndex = 49;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButtonAdd
            // 
            this.toolStripButtonAdd.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripButtonAdd.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonAdd.Image")));
            this.toolStripButtonAdd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonAdd.Name = "toolStripButtonAdd";
            this.toolStripButtonAdd.Size = new System.Drawing.Size(49, 22);
            this.toolStripButtonAdd.Text = "Add";
            this.toolStripButtonAdd.Click += new System.EventHandler(this.toolStripButtonAdd_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButtonExit
            // 
            this.toolStripButtonExit.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripButtonExit.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonExit.Image")));
            this.toolStripButtonExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonExit.Name = "toolStripButtonExit";
            this.toolStripButtonExit.Size = new System.Drawing.Size(48, 22);
            this.toolStripButtonExit.Text = "Exit";
            this.toolStripButtonExit.Click += new System.EventHandler(this.toolStripButtonExit_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnCancel.Image")));
            this.btnCancel.Location = new System.Drawing.Point(895, 635);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(95, 50);
            this.btnCancel.TabIndex = 21;
            this.btnCancel.Text = "Clear";
            this.btnCancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.Location = new System.Drawing.Point(790, 635);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(95, 50);
            this.btnSave.TabIndex = 20;
            this.btnSave.Text = "Save";
            this.btnSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // pbCitizenIdCard
            // 
            this.pbCitizenIdCard.BackColor = System.Drawing.Color.White;
            this.pbCitizenIdCard.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbCitizenIdCard.Location = new System.Drawing.Point(20, 355);
            this.pbCitizenIdCard.Name = "pbCitizenIdCard";
            this.pbCitizenIdCard.Size = new System.Drawing.Size(258, 146);
            this.pbCitizenIdCard.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbCitizenIdCard.TabIndex = 14;
            this.pbCitizenIdCard.TabStop = false;
            // 
            // pbIamge
            // 
            this.pbIamge.BackColor = System.Drawing.Color.White;
            this.pbIamge.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbIamge.Location = new System.Drawing.Point(20, 70);
            this.pbIamge.Name = "pbIamge";
            this.pbIamge.Size = new System.Drawing.Size(180, 216);
            this.pbIamge.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbIamge.TabIndex = 13;
            this.pbIamge.TabStop = false;
            // 
            // cboOccupation
            // 
            this.cboOccupation.DisplayMember = "OccupationNameEN";
            this.cboOccupation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboOccupation.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cboOccupation.FormattingEnabled = true;
            this.cboOccupation.Location = new System.Drawing.Point(790, 270);
            this.cboOccupation.Name = "cboOccupation";
            this.cboOccupation.Size = new System.Drawing.Size(200, 26);
            this.cboOccupation.TabIndex = 9;
            this.cboOccupation.Enter += new System.EventHandler(this.cboOccupation_Enter);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(650, 273);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(84, 18);
            this.label21.TabIndex = 53;
            this.label21.Text = "Occupation";
            // 
            // ucManageCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.cboOccupation);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.txtRoad);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.txtSoi);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.cboProvince);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.cboDistrict);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.cboSubdistrict);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.dtpDateOfBirth);
            this.Controls.Add(this.txtTitleEN);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txtMobileNo);
            this.Controls.Add(this.txtCitizenId);
            this.Controls.Add(this.txtLastNameEN);
            this.Controls.Add(this.txtMiddleNameEN);
            this.Controls.Add(this.txtFirstNameEN);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.cboTitleTH);
            this.Controls.Add(this.txtZipCode);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.txtEMail);
            this.Controls.Add(this.txtLastNameTH);
            this.Controls.Add(this.txtMiddleNameTH);
            this.Controls.Add(this.txtFirstNameTH);
            this.Controls.Add(this.txtAccountNo);
            this.Controls.Add(this.btnCitizenIdCard);
            this.Controls.Add(this.btnImage);
            this.Controls.Add(this.pbCitizenIdCard);
            this.Controls.Add(this.pbIamge);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ucManageCustomer";
            this.Size = new System.Drawing.Size(1008, 705);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCitizenIdCard)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbIamge)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PictureBox pbIamge;
        private System.Windows.Forms.PictureBox pbCitizenIdCard;
        private System.Windows.Forms.Button btnImage;
        private System.Windows.Forms.Button btnCitizenIdCard;
        private System.Windows.Forms.TextBox txtAccountNo;
        private System.Windows.Forms.TextBox txtFirstNameTH;
        private System.Windows.Forms.TextBox txtMiddleNameTH;
        private System.Windows.Forms.TextBox txtLastNameTH;
        private System.Windows.Forms.TextBox txtEMail;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtZipCode;
        private System.Windows.Forms.ComboBox cboTitleTH;
        private System.Windows.Forms.TextBox txtMiddleNameEN;
        private System.Windows.Forms.TextBox txtFirstNameEN;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.MaskedTextBox txtCitizenId;
        private System.Windows.Forms.MaskedTextBox txtMobileNo;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtTitleEN;
        private System.Windows.Forms.DateTimePicker dtpDateOfBirth;
        private System.Windows.Forms.ComboBox cboSubdistrict;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox cboDistrict;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox cboProvince;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtSoi;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtRoad;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtLastNameEN;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButtonAdd;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton toolStripButtonExit;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.ComboBox cboOccupation;
        private System.Windows.Forms.Label label21;
    }
}
