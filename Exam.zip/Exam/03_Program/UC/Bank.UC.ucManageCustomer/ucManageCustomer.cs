﻿using System;
using System.Windows.Forms;
using Bank.Lib.Data;
using Bank.Lib.ConfigurationXML;
using Bank.Lib.UIBusiness;
using System.Linq;
using System.Collections.Generic;
using System.IO;
using System.Configuration;
using System.Drawing;

namespace Bank.UC.ucManageCustomer
{
    public partial class ucManageCustomer : UserControl
    {
        private UserProfile UserProfile = new UserProfile();
        private ApiConfiguration ApiConfiguration = new ApiConfiguration();
        private AllMaster AllMaster = new AllMaster();

        private string ImageBase64 = string.Empty;
        private string ImageExtension = string.Empty;
        private string CitizenIdCardImageBase64 = string.Empty;
        private string CitizenIdCardImageExtension = string.Empty;

        public ucManageCustomer()
        {
            InitializeComponent();
        }

        public ucManageCustomer(UserProfile userProfile, ApiConfiguration apiConfiguration, AllMaster allMaster)
        {
            InitializeComponent();
            UserProfile = userProfile;
            ApiConfiguration = apiConfiguration;
            AllMaster = allMaster;
            try
            {
                if(AllMaster.AllTitle != null && AllMaster.AllTitle.Count > 0)
                {
                    cboTitleTH.DataSource = AllMaster.AllTitle;
                    cboTitleTH.SelectedIndex = -1;
                }

                if (AllMaster.AllProvince != null && AllMaster.AllProvince.Count > 0)
                {
                    cboProvince.DataSource = AllMaster.AllProvince;
                    cboProvince.SelectedIndex = -1;
                }

                if (AllMaster.AllOccupation != null && AllMaster.AllOccupation.Count > 0)
                {
                    cboOccupation.DataSource = AllMaster.AllOccupation;
                    cboOccupation.SelectedIndex = -1;
                }

                ClearData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Dispose();
            }
        }

        private void btnImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog fdlg = new OpenFileDialog();
            fdlg.Title = "Open File Dialog";
            fdlg.Filter = ConfigurationManager.AppSettings["FilterForFile"].ToString();
            fdlg.FilterIndex = 1;
            fdlg.RestoreDirectory = true;

            ImageBase64 = string.Empty;
            if (fdlg.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    Image image = Image.FromFile(fdlg.FileName);
                    pbIamge.Image = image;
                    ImageBase64 = DoBusiness.ConvertImageToBase64String(image);
                    ImageExtension = System.IO.Path.GetExtension(fdlg.SafeFileName);
                    //File.WriteAllBytes(@"d:\yourfile.jpg", Convert.FromBase64String(ImageBase64));
                }
                catch (IOException ex)
                {
                    MessageBox.Show("Error : " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error : " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnCitizenIdCard_Click(object sender, EventArgs e)
        {
            OpenFileDialog fdlg = new OpenFileDialog();
            fdlg.Title = "Open File Dialog";
            fdlg.Filter = ConfigurationManager.AppSettings["FilterForFile"].ToString();
            fdlg.FilterIndex = 1;
            fdlg.RestoreDirectory = true;

            CitizenIdCardImageBase64 = string.Empty;
            if (fdlg.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    Image image = Image.FromFile(fdlg.FileName);
                    pbCitizenIdCard.Image = image;
                    CitizenIdCardImageBase64 = DoBusiness.ConvertImageToBase64String(image);
                    CitizenIdCardImageExtension = System.IO.Path.GetExtension(fdlg.SafeFileName);
                }
                catch (IOException ex)
                {
                    MessageBox.Show("Error : " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error : " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void toolStripButtonAdd_Click(object sender, EventArgs e)
        {
            ClearData();
        }

        private void toolStripButtonExit_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            Cursor = Cursors.WaitCursor;
            try
            {
                if (string.IsNullOrEmpty(txtAccountNo.Text))
                {
                    MessageBox.Show("Please input Account No", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtAccountNo.Focus();
                }
                else if (cboTitleTH.SelectedIndex == -1)
                {
                    MessageBox.Show("Please select Title (TH)", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    cboTitleTH.Focus();
                }
                else if (string.IsNullOrEmpty(txtFirstNameTH.Text))
                {
                    MessageBox.Show("Please input First Name (TH)", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtFirstNameTH.Focus();
                }
                else if (string.IsNullOrEmpty(txtMiddleNameTH.Text))
                {
                    MessageBox.Show("Please input Middle Name (TH)", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtMiddleNameTH.Focus();
                }
                else if (string.IsNullOrEmpty(txtLastNameTH.Text))
                {
                    MessageBox.Show("Please input Last Name (TH)", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtLastNameTH.Focus();
                }
                else if (string.IsNullOrEmpty(txtFirstNameEN.Text))
                {
                    MessageBox.Show("Please input First Name (EN)", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtFirstNameEN.Focus();
                }
                else if (string.IsNullOrEmpty(txtMiddleNameEN.Text))
                {
                    MessageBox.Show("Please input Middle Name (EN)", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtMiddleNameEN.Focus();
                }
                else if (string.IsNullOrEmpty(txtLastNameEN.Text))
                {
                    MessageBox.Show("Please input Last Name (EN)", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtLastNameEN.Focus();
                }
                else if (string.IsNullOrEmpty(txtCitizenId.Text.Replace("-", "").Trim()))
                {
                    MessageBox.Show("Please input Citizen Id", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtCitizenId.Focus();
                }
                else if (cboOccupation.SelectedIndex == -1)
                {
                    MessageBox.Show("Please select Occupation", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    cboOccupation.Focus();
                }
                else if (string.IsNullOrEmpty(dtpDateOfBirth.Text))
                {
                    MessageBox.Show("Please input Date Of Birth", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dtpDateOfBirth.Focus();
                }
                else if (string.IsNullOrEmpty(txtMobileNo.Text.Replace("-", "").Trim()))
                {
                    MessageBox.Show("Please input Mobile No", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtMobileNo.Focus();
                }
                else if (string.IsNullOrEmpty(txtEMail.Text))
                {
                    MessageBox.Show("Please input E-mail", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtEMail.Focus();
                }
                else if (!DoBusiness.CheckEMail(txtEMail.Text))
                {
                    MessageBox.Show("Please input right E-mail", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtEMail.Focus();
                }
                //else if (string.IsNullOrEmpty(txtAddress.Text))
                //{
                //    MessageBox.Show("Please input Address", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //    txtAddress.Focus();
                //}
                //else if (string.IsNullOrEmpty(txtSoi.Text))
                //{
                //    MessageBox.Show("Please input Soi / Trok", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //    txtSoi.Focus();
                //}
                //else if (string.IsNullOrEmpty(txtRoad.Text))
                //{
                //    MessageBox.Show("Please input Road", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //    txtRoad.Focus();
                //}
                else if (cboSubdistrict.SelectedIndex == -1)
                {
                    MessageBox.Show("Please select Subdistrict", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    cboSubdistrict.Focus();
                }
                else if (cboDistrict.SelectedIndex == -1)
                {
                    MessageBox.Show("Please select District", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    cboDistrict.Focus();
                }
                else if (cboProvince.SelectedIndex == -1)
                {
                    MessageBox.Show("Please select Province", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    cboProvince.Focus();
                }
                else if (string.IsNullOrEmpty(txtZipCode.Text))
                {
                    MessageBox.Show("Please input Zip Code", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtZipCode.Focus();
                }
                else if (pbIamge.Image == null)
                {
                    MessageBox.Show("Please select Image", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    btnImage.Focus();
                }
                else if (pbCitizenIdCard.Image == null)
                {
                    MessageBox.Show("Please select Citizen Id Card", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    btnCitizenIdCard.Focus();
                }
                else
                {
                    Customer request = new Customer();
                    request.AccountNo = txtAccountNo.Text;
                    request.TitleCode = AllMaster.AllTitle[cboTitleTH.SelectedIndex].TitleCode;

                    request.FirstNameTH = txtFirstNameTH.Text;
                    request.MiddleNameTH = txtMiddleNameTH.Text;
                    request.LastNameTH = txtLastNameTH.Text;

                    request.FirstNameEN = txtFirstNameEN.Text;
                    request.MiddleNameEN = txtMiddleNameEN.Text;
                    request.LastNameEN = txtLastNameEN.Text;

                    request.CitizenId = txtCitizenId.Text.Replace("-", "").Trim();

                    //request.FirstNameTH = Bank.Lib.DataSecurity.EncryptDecrypt_MD5.GetDecrypt(txtFirstNameTH.Text);
                    //request.MiddleNameTH = Bank.Lib.DataSecurity.EncryptDecrypt_MD5.GetDecrypt(txtMiddleNameTH.Text);
                    //request.LastNameTH = Bank.Lib.DataSecurity.EncryptDecrypt_MD5.GetDecrypt(txtLastNameTH.Text);

                    //request.FirstNameEN = Bank.Lib.DataSecurity.EncryptDecrypt_MD5.GetDecrypt(txtFirstNameEN.Text);
                    //request.MiddleNameEN = Bank.Lib.DataSecurity.EncryptDecrypt_MD5.GetDecrypt(txtMiddleNameEN.Text);
                    //request.LastNameEN = Bank.Lib.DataSecurity.EncryptDecrypt_MD5.GetDecrypt(txtLastNameEN.Text);

                    //request.CitizenId = Bank.Lib.DataSecurity.EncryptDecrypt_MD5.GetDecrypt(txtCitizenId.Text.Replace("-",""));

                    request.DateOfBirth = dtpDateOfBirth.Text;
                    request.MobileNo = txtMobileNo.Text.Replace("-", "").Trim();
                    request.EMail = txtEMail.Text;
                    request.Address = txtAddress.Text;

                    request.Soi = txtSoi.Text;
                    request.Road = txtRoad.Text;
                    request.SubdistrictCode = SubDistrictCode;
                    request.DistrictCode = DistrictCode;
                    request.ProvinceCode = ProvinceCode;

                    request.ZipCode = txtZipCode.Text;

                    request.BranchCode = UserProfile.ManageUser.BranchCode;
                    request.OccupationCode = AllMaster.AllOccupation[cboOccupation.SelectedIndex].OccupationCode;
                    request.IsSendCitizenCard = "N";
                    request.IsSendImage = "N";
                    request.CreatedBy = UserProfile.ManageUser.UserName;
                    request.ModifiedBy = UserProfile.ManageUser.UserName;
                    string MiddleTH = " ";
                    string MiddleEN = " ";

                    if (txtMiddleNameTH.Text.Trim().Length > 0)
                    {
                        MiddleTH = " " + txtMiddleNameTH.Text + " ";
                    }

                    if (txtMiddleNameTH.Text.Trim().Length > 0)
                    {
                        MiddleEN = " " + txtMiddleNameEN.Text + " ";
                    }

                    request.FullNameTH = txtFirstNameTH.Text.Trim() + MiddleTH + txtLastNameTH.Text.Trim();
                    request.FullNameEN = txtFirstNameEN.Text.Trim() + MiddleEN + txtLastNameEN.Text.Trim();

                    request.ImageBase64 = ImageBase64;
                    request.ImageExtension = ImageExtension;
                    request.CitizenIdCardImageBase64 = CitizenIdCardImageBase64;
                    request.CitizenIdCardImageExtension = CitizenIdCardImageExtension;

                    bool isSuccess = false;
                    string errorMessage = string.Empty;
                    CallAPIBusiness bs = new CallAPIBusiness(UserProfile, ApiConfiguration, InterfaceServiceName.InsertCustomer);
                    ResultResponse response = bs.CallExternalAPI<ResultResponse, Customer>(request, ref isSuccess, ref errorMessage);
                    if (!isSuccess)
                    {
                        MessageBox.Show(errorMessage, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        if (response.MessageCode.ToUpper().Equals("SUCCESS"))
                        {
                            MessageBox.Show(response.MessageDesc, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show(response.MessageDesc, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ClearData();
        }

        private void ClearData()
        {
            txtAccountNo.Clear();
            cboTitleTH.SelectedIndex = -1;
            txtFirstNameTH.Clear();
            txtMiddleNameTH.Clear();
            txtLastNameTH.Clear();

            txtTitleEN.Clear();
            txtFirstNameEN.Clear();
            txtMiddleNameEN.Clear();
            txtLastNameEN.Clear();

            txtCitizenId.Clear();
            dtpDateOfBirth.Value = DateTime.Now;

            txtMobileNo.Clear();
            txtEMail.Clear();
            txtAddress.Clear();
            txtSoi.Clear();
            txtRoad.Clear();

            cboSubdistrict.SelectedIndex = -1;
            cboDistrict.SelectedIndex = -1;
            cboProvince.SelectedIndex = -1;

            if (cboDistrict.Items != null)
            {
                cboDistrict.DataSource = new List<District>();
            }
            if (cboSubdistrict.Items != null)
            {
                cboSubdistrict.DataSource = new List<SubDistrict>();
            }
            txtZipCode.Clear();
            pbIamge.Image = null;
            pbCitizenIdCard.Image = null;
        }

        private void cboTitleTH_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboTitleTH.SelectedIndex > -1)
            {
                txtTitleEN.Text = AllMaster.AllTitle[cboTitleTH.SelectedIndex].TitleNameEN;
            }
        }

        private string ProvinceCode = string.Empty;
        private string DistrictCode = string.Empty;
        private string SubDistrictCode = string.Empty;
        private void cboProvince_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboProvince.SelectedIndex > -1)
            {
                ProvinceCode = AllMaster.AllProvince[cboProvince.SelectedIndex].ProvinceCode;
                DistrictCode = string.Empty;
                SubDistrictCode = string.Empty;
                if (AllMaster.AllDistrict != null && AllMaster.AllDistrict.Count > 0)
                {
                    cboDistrict.DataSource = AllMaster.AllDistrict.Where(x => x.ProvinceCode.Equals(ProvinceCode)).ToList();
                    cboDistrict.SelectedIndex = -1;
                    cboSubdistrict.DataSource = new List<SubDistrict>();
                }
            }
            txtZipCode.Clear();
        }

        private void cboDistrict_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboDistrict.SelectedIndex > -1)
            {
                DistrictCode = AllMaster.AllDistrict[cboDistrict.SelectedIndex].DistrictCode;
                SubDistrictCode = string.Empty;
                if (AllMaster.AllSubDistrict != null && AllMaster.AllSubDistrict.Count > 0)
                {
                    cboSubdistrict.DataSource = AllMaster.AllSubDistrict.Where(x => x.ProvinceCode.Equals(ProvinceCode) && x.DistrictCode.Equals(DistrictCode)).ToList();
                    cboSubdistrict.SelectedIndex = -1;
                }
            }
            txtZipCode.Clear();
        }

        private void cboSubdistrict_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboSubdistrict.SelectedIndex > -1)
            {
                SubDistrictCode = AllMaster.AllSubDistrict.Where(x => x.ProvinceCode.Equals(ProvinceCode) && x.DistrictCode.Equals(DistrictCode)).ToList()[cboSubdistrict.SelectedIndex].SubDistrictCode;
                txtZipCode.Text = AllMaster.AllSubDistrict.Where(x => x.ProvinceCode.Equals(ProvinceCode) && x.DistrictCode.Equals(DistrictCode)).ToList()[cboSubdistrict.SelectedIndex].ZipCode;
            }
        }

        #region Set Language
        private void txtAccountNo_Enter(object sender, EventArgs e)
        {
            Application.CurrentInputLanguage = InputLanguage.FromCulture(new System.Globalization.CultureInfo("en-US"));
        }

        private void cboTitleTH_Enter(object sender, EventArgs e)
        {
            Application.CurrentInputLanguage = InputLanguage.FromCulture(new System.Globalization.CultureInfo("th-TH"));
        }

        private void txtFirstNameTH_Enter(object sender, EventArgs e)
        {
            Application.CurrentInputLanguage = InputLanguage.FromCulture(new System.Globalization.CultureInfo("th-TH"));
        }

        private void txtMiddleNameTH_Enter(object sender, EventArgs e)
        {
            Application.CurrentInputLanguage = InputLanguage.FromCulture(new System.Globalization.CultureInfo("th-TH"));
        }

        private void txtLastNameTH_Enter(object sender, EventArgs e)
        {
            Application.CurrentInputLanguage = InputLanguage.FromCulture(new System.Globalization.CultureInfo("th-TH"));
        }

        private void txtFirstNameEN_Enter(object sender, EventArgs e)
        {
            Application.CurrentInputLanguage = InputLanguage.FromCulture(new System.Globalization.CultureInfo("en-US"));
        }

        private void txtMiddleNameEN_Enter(object sender, EventArgs e)
        {
            Application.CurrentInputLanguage = InputLanguage.FromCulture(new System.Globalization.CultureInfo("en-US"));
        }

        private void txtLastNameEN_Enter(object sender, EventArgs e)
        {
            Application.CurrentInputLanguage = InputLanguage.FromCulture(new System.Globalization.CultureInfo("en-US"));
        }

        private void txtCitizenId_Enter(object sender, EventArgs e)
        {
            Application.CurrentInputLanguage = InputLanguage.FromCulture(new System.Globalization.CultureInfo("en-US"));
        }

        private void cboOccupation_Enter(object sender, EventArgs e)
        {
            Application.CurrentInputLanguage = InputLanguage.FromCulture(new System.Globalization.CultureInfo("en-US"));
        }

        private void dtpDateOfBirth_Enter(object sender, EventArgs e)
        {
            Application.CurrentInputLanguage = InputLanguage.FromCulture(new System.Globalization.CultureInfo("en-US"));
        }

        private void txtMobileNo_Enter(object sender, EventArgs e)
        {
            Application.CurrentInputLanguage = InputLanguage.FromCulture(new System.Globalization.CultureInfo("en-US"));
        }

        private void txtEMail_Enter(object sender, EventArgs e)
        {
            Application.CurrentInputLanguage = InputLanguage.FromCulture(new System.Globalization.CultureInfo("en-US"));
        }

        private void txtAddress_Enter(object sender, EventArgs e)
        {
            Application.CurrentInputLanguage = InputLanguage.FromCulture(new System.Globalization.CultureInfo("en-US"));
        }

        private void txtSoi_Enter(object sender, EventArgs e)
        {
            Application.CurrentInputLanguage = InputLanguage.FromCulture(new System.Globalization.CultureInfo("en-US"));
        }

        private void txtRoad_Enter(object sender, EventArgs e)
        {
            Application.CurrentInputLanguage = InputLanguage.FromCulture(new System.Globalization.CultureInfo("en-US"));
        }

        private void cboSubdistrict_Enter(object sender, EventArgs e)
        {
            Application.CurrentInputLanguage = InputLanguage.FromCulture(new System.Globalization.CultureInfo("en-US"));
        }

        private void cboDistrict_Enter(object sender, EventArgs e)
        {
            Application.CurrentInputLanguage = InputLanguage.FromCulture(new System.Globalization.CultureInfo("en-US"));
        }

        private void cboProvince_Enter(object sender, EventArgs e)
        {
            Application.CurrentInputLanguage = InputLanguage.FromCulture(new System.Globalization.CultureInfo("en-US"));
        }

        private void txtZipCode_Enter(object sender, EventArgs e)
        {
            Application.CurrentInputLanguage = InputLanguage.FromCulture(new System.Globalization.CultureInfo("en-US"));
        }
        #endregion
    }
}
