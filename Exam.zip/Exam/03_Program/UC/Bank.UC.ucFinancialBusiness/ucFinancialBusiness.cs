﻿using System;
using System.Windows.Forms;
using Bank.Lib.Data;
using Bank.Lib.ConfigurationXML;
using Bank.Lib.UIBusiness;
using System.Linq;

namespace Bank.UC.ucFinancialBusiness
{
    public partial class ucFinancialBusiness : UserControl
    {
        private UserProfile UserProfile = new UserProfile();
        private ApiConfiguration ApiConfiguration = new ApiConfiguration();
        private AllMaster AllMaster = new AllMaster();

        private bool _isSuccess = false;
        private string _errorMessage = string.Empty;

        private string _accountNo = string.Empty;
        private string _accountNoTransfer = string.Empty;

        private CustomerList _customerList = new CustomerList();
        private CustomerList _customerListTransfer = new CustomerList();

        public ucFinancialBusiness()
        {
            InitializeComponent();
        }

        public ucFinancialBusiness(UserProfile userProfile, ApiConfiguration apiConfiguration, AllMaster allMaster)
        {
            InitializeComponent();
            UserProfile = userProfile;
            ApiConfiguration = apiConfiguration;
            AllMaster = allMaster;
            
            try
            {
                if (AllMaster.AllTypeFinancial != null && AllMaster.AllTypeFinancial.Count > 0)
                {
                    cboTypeOfFinancial.DataSource = AllMaster.AllTypeFinancial;//.Select(person => person.TitleNameTH).ToArray();
                    cboTypeOfFinancial.SelectedIndex = -1;
                }

                ClearData(true, true, true);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Dispose();
            }
        }

        private void toolStripButtonExit_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txtAccountNo.Text) && string.IsNullOrEmpty(txtCitizenId.Text.Replace("-", "").Trim()))
                {
                    MessageBox.Show("Please input Account No or Citizen Id", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtAccountNo.Focus();
                }
                else
                {
                    txtBalance.Clear();
                    txtAvailable.Clear();
                    _customerList = SearchCustomer(DgvShowAccountNo, txtBalance, false, 0, txtAccountNo.Text, txtCitizenId.Text, false);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearData(false, true, false);
        }

        private void btnSearchTransfer_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txtAccountNoTransfer.Text) && string.IsNullOrEmpty(txtCitizenIdTransfer.Text.Replace("-", "").Trim()))
                {
                    MessageBox.Show("Please input Account No or Citizen Id", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtAccountNoTransfer.Focus();
                }
                else
                {
                    txtBalanceTransfer.Clear();
                    _customerListTransfer = SearchCustomer(DgvShowAccountNoTransfer, txtBalanceTransfer, false, 0, txtAccountNoTransfer.Text, txtCitizenIdTransfer.Text, true);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClearTransfer_Click(object sender, EventArgs e)
        {
            ClearData(false, false, true);
        }

        private CustomerList SearchCustomer(System.Windows.Forms.DataGridView dgv, System.Windows.Forms.TextBox txtbox, bool isSendRowIndex, int defaultIndexRows, string AccountNo, string CitizenId, bool isTransfer)
        {
            CustomerList response = new CustomerList();
            try
            {
                this.Cursor = Cursors.WaitCursor;
                if (dgv.RowCount > 0)
                {
                    dgv.Rows.Clear();
                }
                CustomerForSearch request = new CustomerForSearch();
                request.AccountNo = AccountNo;
                request.CitizenId = CitizenId.Replace("-", "").Trim();

                CallAPIBusiness bs = new CallAPIBusiness(UserProfile, ApiConfiguration, InterfaceServiceName.CheckCustomer);
                response = bs.CallExternalAPI<CustomerList, CustomerForSearch>(request, ref _isSuccess, ref _errorMessage);
                if (!_isSuccess)
                {
                    MessageBox.Show(_errorMessage, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    if (response.MessageCode.ToUpper().Equals("SUCCESS"))
                    {
                        for (int i = 0; i < response.ObjectList.Count; i++)
                        {
                            dgv.Rows.Add(response.ObjectList[i].AccountNo);
                        }
                        //dgv.Rows[0].Selected = true;
                        if (isTransfer)
                        {
                            ClickGrid(dgv, txtbox, response, isSendRowIndex, defaultIndexRows, isTransfer, ref _accountNoTransfer);
                        }
                        else
                        {
                            ClickGrid(dgv, txtbox, response, isSendRowIndex, defaultIndexRows, isTransfer, ref _accountNo);
                        }

                        dgv.ClearSelection();
                        dgv.Rows[defaultIndexRows].Cells[0].Selected = true;
                    }
                    else
                    {
                        MessageBox.Show(response.MessageDesc, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Cursor = Cursors.Default;
            }
            return response;
        }

        private void ClearData(bool IsClearAll, bool IsClear, bool IsClearTransfer)
        {
            if (IsClearAll)
            {
                cboTypeOfFinancial.SelectedIndex = -1;
            }

            if (IsClear)
            {
                txtAccountNo.Clear();
                txtCitizenId.Clear();
                txtBalance.Clear();

                txtAvailable.Clear();

                txtShowFullNameTH.Clear();
                txtShowFullNameEN.Clear();
                txtShowCitizenId.Clear();
                if (DgvShowAccountNo.RowCount > 0)
                {
                    DgvShowAccountNo.Rows.Clear();
                }
            }

            if (IsClearTransfer)
            {
                txtAccountNoTransfer.Clear();
                txtCitizenIdTransfer.Clear();
                txtBalanceTransfer.Clear();

                txtShowFullNameTHTransfer.Clear();
                txtShowFullNameENTransfer.Clear();
                txtShowCitizenIdTransfer.Clear();

                if (DgvShowAccountNoTransfer.RowCount > 0)
                {
                    DgvShowAccountNoTransfer.Rows.Clear();
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                this.Cursor = Cursors.WaitCursor;
                if (DgvShowAccountNo.RowCount == 0)
                {
                    MessageBox.Show("Please search Account No before " + lblAvailable.Text, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    DgvShowAccountNo.Focus();
                }
                else if (string.IsNullOrEmpty(txtBalance.Text))
                {
                    MessageBox.Show("Please select Account No before " + lblAvailable.Text, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtBalance.Focus();
                }
                else if (string.IsNullOrEmpty(txtAvailable.Text))
                {
                    MessageBox.Show("Please input " + lblAvailable.Text, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtAvailable.Focus();
                }
                else if (!DoBusiness.CheckIsNumber(txtAvailable.Text))
                {
                    MessageBox.Show("Please input number", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtAvailable.Focus();
                }
                else if ((cboTypeOfFinancial.SelectedIndex == 1 || cboTypeOfFinancial.SelectedIndex == 2) && !DoBusiness.CheckMoneyForSave(txtBalance.Text, txtAvailable.Text.Trim()))
                {
                    MessageBox.Show("Please check money for " + lblAvailable.Text, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtAvailable.Focus();
                }
                else if ((cboTypeOfFinancial.SelectedIndex == 2) && DgvShowAccountNoTransfer.RowCount == 0)
                {
                    MessageBox.Show("Please check Account No for " + lblAvailable.Text, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    DgvShowAccountNoTransfer.Focus();
                }
                else if ((cboTypeOfFinancial.SelectedIndex == 2) && DgvShowAccountNoTransfer.CurrentCell.RowIndex < 0)
                {
                    MessageBox.Show("Please select Account No for " + lblAvailable.Text, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    DgvShowAccountNoTransfer.Focus();
                }
                else if ((cboTypeOfFinancial.SelectedIndex == 2) && _accountNo.Equals(_accountNoTransfer))
                {
                    MessageBox.Show("Please not select same Account No", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    DgvShowAccountNoTransfer.Focus();
                }
                else
                {
                    int defaultIndexRows = DgvShowAccountNo.CurrentCell.RowIndex;
                    int defaultIndexRowsTransfer = 0;
                    if (cboTypeOfFinancial.SelectedIndex == 2)
                    {
                        defaultIndexRowsTransfer = DgvShowAccountNoTransfer.CurrentCell.RowIndex;
                    }
                    string TypeFinancial = AllMaster.AllTypeFinancial[cboTypeOfFinancial.SelectedIndex].TypeFinancialNameEN;
                    FinancialTransaction request = new FinancialTransaction();
                    request.TypeFinancialCode = TypeFinancial;
                    request.ChannelCode = "BANK";
                    request.BranchCode = UserProfile.ManageUser.BranchCode;
                    request.AccountNo = _accountNo;
                    //request.TypeCash = "";

                    request.FeeAmount = 0;
                    request.Amount = Convert.ToDecimal(txtAvailable.Text);

                    request.MemoMessage = "";
                    request.Description = "";
                    request.TransactionBy = UserProfile.ManageUser.UserName;

                    //request.RelatedBankCode = "";
                    //request.RelatedAccountNo = "";
                    if (TypeFinancial.ToUpper().Equals("TRANSFER"))
                    {
                        request.IsSameBank = "Y";
                        request.TypeCash = "OUT";
                        request.RelatedBankCode = "MYBANK";
                        request.RelatedAccountNo = _accountNoTransfer;
                    }
                    else if (TypeFinancial.ToUpper().Equals("DEPOSIT"))
                    {
                        request.IsSameBank = "N";
                        request.TypeCash = "IN";
                    }
                    else if (TypeFinancial.ToUpper().Equals("WITHDRAW"))
                    {
                        request.IsSameBank = "N";
                        request.TypeCash = "OUT";
                    }

                    CallAPIBusiness bs = new CallAPIBusiness(UserProfile, ApiConfiguration, InterfaceServiceName.InsertFinancialTransaction);
                    ResultResponse response = bs.CallExternalAPI<ResultResponse, FinancialTransaction>(request, ref _isSuccess, ref _errorMessage);
                    if (!_isSuccess)
                    {
                        MessageBox.Show(_errorMessage, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        if (response.MessageCode.ToUpper().Equals("SUCCESS"))
                        {
                            MessageBox.Show(response.MessageDesc, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            _customerList = SearchCustomer(DgvShowAccountNo, txtBalance, true, defaultIndexRows, txtAccountNo.Text, txtCitizenId.Text, false);
                            if (_customerList.MessageCode.ToUpper().Equals("SUCCESS"))
                            {
                                txtAvailable.Clear();

                                if (cboTypeOfFinancial.SelectedIndex == 2)
                                {
                                    _customerListTransfer = SearchCustomer(DgvShowAccountNoTransfer, txtBalanceTransfer, true, defaultIndexRowsTransfer, txtAccountNoTransfer.Text, txtCitizenIdTransfer.Text, true);
                                }
                            }
                            else
                            {
                                MessageBox.Show(_customerList.MessageDesc, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                        }
                        else
                        {
                            MessageBox.Show(response.MessageDesc, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ClearData(true, true, true);
        }

        private void cboTypeOfFinancial_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboTypeOfFinancial.SelectedIndex > -1)
            {
                groupBox2.Enabled = true;
                ClearData(false, true, true);
                btnSave.Enabled = true;
                btnCancel.Enabled = true;
                if (cboTypeOfFinancial.SelectedIndex == 0)
                {
                    groupBox3.Enabled = false;
                    lblAvailable.Text = "Deposit";
                    groupBox2.Text = "Deposit";
                    groupBox3.Text = "";
                }
                else if (cboTypeOfFinancial.SelectedIndex == 1)
                {
                    groupBox3.Enabled = false;
                    lblAvailable.Text = "Withdraw";
                    groupBox2.Text = "Withdraw";
                    groupBox3.Text = "";
                }
                else if (cboTypeOfFinancial.SelectedIndex == 2)
                {
                    groupBox3.Enabled = true;
                    lblAvailable.Text = "Transfer";
                    groupBox2.Text = "Transfer From";
                    groupBox3.Text = "Transfer To";
                }
            }
            else
            {
                groupBox2.Enabled = false;
                groupBox3.Enabled = false;
                lblAvailable.Text = "";
                btnSave.Enabled = false;
                btnCancel.Enabled = false;
            }
        }

        private void DgvShowAccountNo_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            ClickGrid(DgvShowAccountNo, txtBalance, _customerList, false, 0, false, ref _accountNo);
        }

        private void DgvShowAccountNo_Click(object sender, EventArgs e)
        {
            ClickGrid(DgvShowAccountNo, txtBalance, _customerList, false, 0, false, ref _accountNo);
        }

        private void DgvShowAccountNo_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Down || e.KeyCode == Keys.Up)
            {
                ClickGrid(DgvShowAccountNo, txtBalance, _customerList, false, 0, false, ref _accountNo);
            }
        }

        private void DgvShowAccountNoTransfer_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            ClickGrid(DgvShowAccountNoTransfer, txtBalanceTransfer, _customerListTransfer, false, 0, true, ref _accountNoTransfer);
        }

        private void DgvShowAccountNoTransfer_Click(object sender, EventArgs e)
        {
            ClickGrid(DgvShowAccountNoTransfer, txtBalanceTransfer, _customerListTransfer, false, 0, true, ref _accountNoTransfer);
        }

        private void DgvShowAccountNoTransfer_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Down || e.KeyCode == Keys.Up)
            {
                ClickGrid(DgvShowAccountNoTransfer, txtBalanceTransfer, _customerListTransfer, false, 0, true, ref _accountNoTransfer);
            }
        }

        private void ClickGrid(System.Windows.Forms.DataGridView dgv, System.Windows.Forms.TextBox txtbox, CustomerList customerList, bool isSendRowIndex, int defaultIndexRows, bool isTransfer, ref string accountNo)
        {
            try
            {
                this.Cursor = Cursors.WaitCursor;

                if (dgv.CurrentCell != null)
                {
                    if (dgv.SelectedRows != null)
                    {
                        if (dgv.CurrentCell.RowIndex < dgv.RowCount)
                        {
                            int RowIndex = dgv.CurrentCell.RowIndex;
                            if (isSendRowIndex)
                            {
                                RowIndex = defaultIndexRows;
                            }
                            accountNo = dgv[0, RowIndex].Value.ToString();

                            if (customerList.MessageCode.ToUpper().Equals("SUCCESS"))
                            {
                                var check = customerList.ObjectList.Where(x => x.AccountNo.Equals(dgv[0, RowIndex].Value.ToString())).ToList();
                                if(check != null && check.Count > 0)
                                {
                                    txtbox.Text = check[0].Balance.ToString("N2");
                                    if (isTransfer)
                                    {
                                        txtShowFullNameTHTransfer.Text = check[0].FullNameTH;
                                        txtShowFullNameENTransfer.Text = check[0].FullNameEN;
                                        txtShowCitizenIdTransfer.Text = check[0].CitizenId;
                                    }
                                    else
                                    {
                                        txtShowFullNameTH.Text = check[0].FullNameTH;
                                        txtShowFullNameEN.Text = check[0].FullNameEN;
                                        txtShowCitizenId.Text = check[0].CitizenId;
                                    }
                                }
                            }
                            else
                            {
                                MessageBox.Show(customerList.MessageDesc, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error : " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                this.Cursor = Cursors.Default;
            }
        }

        #region Set Language
        private void txtAccountNo_Enter(object sender, EventArgs e)
        {
            Application.CurrentInputLanguage = InputLanguage.FromCulture(new System.Globalization.CultureInfo("en-US"));
        }

        private void txtCitizenId_Enter(object sender, EventArgs e)
        {
            Application.CurrentInputLanguage = InputLanguage.FromCulture(new System.Globalization.CultureInfo("en-US"));
        }

        private void txtAvailable_Enter(object sender, EventArgs e)
        {
            Application.CurrentInputLanguage = InputLanguage.FromCulture(new System.Globalization.CultureInfo("en-US"));
        }

        private void txtAccountNoTransfer_Enter(object sender, EventArgs e)
        {
            Application.CurrentInputLanguage = InputLanguage.FromCulture(new System.Globalization.CultureInfo("en-US"));
        }

        private void txtCitizenIdTransfer_Enter(object sender, EventArgs e)
        {
            Application.CurrentInputLanguage = InputLanguage.FromCulture(new System.Globalization.CultureInfo("en-US"));
        }
        #endregion

        private void txtAvailable_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

    }
}