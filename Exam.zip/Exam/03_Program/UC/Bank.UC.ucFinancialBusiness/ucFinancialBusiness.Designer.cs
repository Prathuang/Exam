﻿namespace Bank.UC.ucFinancialBusiness
{
    partial class ucFinancialBusiness
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucFinancialBusiness));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButtonExit = new System.Windows.Forms.ToolStripButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cboTypeOfFinancial = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.DgvShowAccountNo = new System.Windows.Forms.DataGridView();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtAvailable = new System.Windows.Forms.TextBox();
            this.lblAvailable = new System.Windows.Forms.Label();
            this.txtBalance = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtCitizenId = new System.Windows.Forms.MaskedTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtAccountNo = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.DgvShowAccountNoTransfer = new System.Windows.Forms.DataGridView();
            this.btnClearTransfer = new System.Windows.Forms.Button();
            this.btnSearchTransfer = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtBalanceTransfer = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtCitizenIdTransfer = new System.Windows.Forms.MaskedTextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtAccountNoTransfer = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.AccountNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.txtShowFullNameTH = new System.Windows.Forms.TextBox();
            this.txtShowFullNameEN = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtShowCitizenId = new System.Windows.Forms.MaskedTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtShowCitizenIdTransfer = new System.Windows.Forms.MaskedTextBox();
            this.txtShowFullNameENTransfer = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtShowFullNameTHTransfer = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.toolStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvShowAccountNo)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvShowAccountNoTransfer)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButtonExit});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1008, 25);
            this.toolStrip1.TabIndex = 50;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButtonExit
            // 
            this.toolStripButtonExit.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripButtonExit.Image = global::Bank.UC.ucFinancialBusiness.Properties.Resources.logout;
            this.toolStripButtonExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonExit.Name = "toolStripButtonExit";
            this.toolStripButtonExit.Size = new System.Drawing.Size(48, 22);
            this.toolStripButtonExit.Text = "Exit";
            this.toolStripButtonExit.Click += new System.EventHandler(this.toolStripButtonExit_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cboTypeOfFinancial);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(25, 40);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(958, 80);
            this.groupBox1.TabIndex = 51;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Please Select Type of Financial";
            // 
            // cboTypeOfFinancial
            // 
            this.cboTypeOfFinancial.DisplayMember = "TypeFinancialNameEN";
            this.cboTypeOfFinancial.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTypeOfFinancial.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cboTypeOfFinancial.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboTypeOfFinancial.FormattingEnabled = true;
            this.cboTypeOfFinancial.Location = new System.Drawing.Point(440, 35);
            this.cboTypeOfFinancial.Name = "cboTypeOfFinancial";
            this.cboTypeOfFinancial.Size = new System.Drawing.Size(200, 26);
            this.cboTypeOfFinancial.TabIndex = 0;
            this.cboTypeOfFinancial.SelectedIndexChanged += new System.EventHandler(this.cboTypeOfFinancial_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(307, 38);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(119, 18);
            this.label7.TabIndex = 9;
            this.label7.Text = "Type of Financial";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.txtShowCitizenId);
            this.groupBox2.Controls.Add(this.txtShowFullNameEN);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.txtShowFullNameTH);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.DgvShowAccountNo);
            this.groupBox2.Controls.Add(this.btnClear);
            this.groupBox2.Controls.Add(this.btnSearch);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.txtAvailable);
            this.groupBox2.Controls.Add(this.lblAvailable);
            this.groupBox2.Controls.Add(this.txtBalance);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.txtCitizenId);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.txtAccountNo);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(25, 140);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(958, 230);
            this.groupBox2.TabIndex = 52;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "groupBox2";
            // 
            // DgvShowAccountNo
            // 
            this.DgvShowAccountNo.AllowUserToAddRows = false;
            this.DgvShowAccountNo.AllowUserToDeleteRows = false;
            this.DgvShowAccountNo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvShowAccountNo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.AccountNo});
            this.DgvShowAccountNo.Location = new System.Drawing.Point(360, 25);
            this.DgvShowAccountNo.Name = "DgvShowAccountNo";
            this.DgvShowAccountNo.ReadOnly = true;
            this.DgvShowAccountNo.RowHeadersWidth = 4;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.DgvShowAccountNo.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.DgvShowAccountNo.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.DgvShowAccountNo.RowTemplate.Height = 40;
            this.DgvShowAccountNo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvShowAccountNo.Size = new System.Drawing.Size(250, 190);
            this.DgvShowAccountNo.TabIndex = 7;
            this.DgvShowAccountNo.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvShowAccountNo_CellContentClick);
            this.DgvShowAccountNo.Click += new System.EventHandler(this.DgvShowAccountNo_Click);
            this.DgvShowAccountNo.KeyUp += new System.Windows.Forms.KeyEventHandler(this.DgvShowAccountNo_KeyUp);
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Image = ((System.Drawing.Image)(resources.GetObject("btnClear.Image")));
            this.btnClear.Location = new System.Drawing.Point(240, 175);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(90, 40);
            this.btnClear.TabIndex = 6;
            this.btnClear.Text = "Clear";
            this.btnClear.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Image = ((System.Drawing.Image)(resources.GetObject("btnSearch.Image")));
            this.btnSearch.Location = new System.Drawing.Point(135, 175);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(90, 40);
            this.btnSearch.TabIndex = 5;
            this.btnSearch.Text = "Search";
            this.btnSearch.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(290, 138);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(38, 18);
            this.label13.TabIndex = 37;
            this.label13.Text = "Baht";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(290, 98);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(38, 18);
            this.label12.TabIndex = 36;
            this.label12.Text = "Baht";
            // 
            // txtAvailable
            // 
            this.txtAvailable.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAvailable.Location = new System.Drawing.Point(135, 135);
            this.txtAvailable.MaxLength = 10;
            this.txtAvailable.Name = "txtAvailable";
            this.txtAvailable.Size = new System.Drawing.Size(145, 24);
            this.txtAvailable.TabIndex = 4;
            this.txtAvailable.Enter += new System.EventHandler(this.txtAvailable_Enter);
            this.txtAvailable.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAvailable_KeyPress);
            // 
            // lblAvailable
            // 
            this.lblAvailable.AutoSize = true;
            this.lblAvailable.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAvailable.Location = new System.Drawing.Point(15, 138);
            this.lblAvailable.Name = "lblAvailable";
            this.lblAvailable.Size = new System.Drawing.Size(59, 18);
            this.lblAvailable.TabIndex = 34;
            this.lblAvailable.Text = "Deposit";
            // 
            // txtBalance
            // 
            this.txtBalance.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBalance.Location = new System.Drawing.Point(135, 95);
            this.txtBalance.MaxLength = 200;
            this.txtBalance.Name = "txtBalance";
            this.txtBalance.ReadOnly = true;
            this.txtBalance.Size = new System.Drawing.Size(145, 24);
            this.txtBalance.TabIndex = 3;
            this.txtBalance.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(15, 98);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(61, 18);
            this.label8.TabIndex = 32;
            this.label8.Text = "Balance";
            // 
            // txtCitizenId
            // 
            this.txtCitizenId.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCitizenId.Location = new System.Drawing.Point(135, 60);
            this.txtCitizenId.Mask = "0-0000-00000-00-0";
            this.txtCitizenId.Name = "txtCitizenId";
            this.txtCitizenId.Size = new System.Drawing.Size(195, 24);
            this.txtCitizenId.TabIndex = 2;
            this.txtCitizenId.Enter += new System.EventHandler(this.txtCitizenId_Enter);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(15, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 18);
            this.label3.TabIndex = 15;
            this.label3.Text = "Citizen Id";
            // 
            // txtAccountNo
            // 
            this.txtAccountNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAccountNo.Location = new System.Drawing.Point(135, 25);
            this.txtAccountNo.MaxLength = 30;
            this.txtAccountNo.Name = "txtAccountNo";
            this.txtAccountNo.Size = new System.Drawing.Size(195, 24);
            this.txtAccountNo.TabIndex = 1;
            this.txtAccountNo.Enter += new System.EventHandler(this.txtAccountNo_Enter);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(15, 28);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(86, 18);
            this.label11.TabIndex = 14;
            this.label11.Text = "Account No";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.txtShowCitizenIdTransfer);
            this.groupBox3.Controls.Add(this.txtShowFullNameENTransfer);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.txtShowFullNameTHTransfer);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.DgvShowAccountNoTransfer);
            this.groupBox3.Controls.Add(this.btnClearTransfer);
            this.groupBox3.Controls.Add(this.btnSearchTransfer);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.txtBalanceTransfer);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.txtCitizenIdTransfer);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.txtAccountNoTransfer);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(25, 390);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(958, 230);
            this.groupBox3.TabIndex = 53;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "groupBox3";
            // 
            // DgvShowAccountNoTransfer
            // 
            this.DgvShowAccountNoTransfer.AllowUserToAddRows = false;
            this.DgvShowAccountNoTransfer.AllowUserToDeleteRows = false;
            this.DgvShowAccountNoTransfer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvShowAccountNoTransfer.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1});
            this.DgvShowAccountNoTransfer.Location = new System.Drawing.Point(360, 25);
            this.DgvShowAccountNoTransfer.Name = "DgvShowAccountNoTransfer";
            this.DgvShowAccountNoTransfer.ReadOnly = true;
            this.DgvShowAccountNoTransfer.RowHeadersWidth = 4;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.DgvShowAccountNoTransfer.RowsDefaultCellStyle = dataGridViewCellStyle8;
            this.DgvShowAccountNoTransfer.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.DgvShowAccountNoTransfer.RowTemplate.Height = 40;
            this.DgvShowAccountNoTransfer.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvShowAccountNoTransfer.Size = new System.Drawing.Size(250, 190);
            this.DgvShowAccountNoTransfer.TabIndex = 13;
            this.DgvShowAccountNoTransfer.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvShowAccountNoTransfer_CellContentClick);
            this.DgvShowAccountNoTransfer.Click += new System.EventHandler(this.DgvShowAccountNoTransfer_Click);
            this.DgvShowAccountNoTransfer.KeyUp += new System.Windows.Forms.KeyEventHandler(this.DgvShowAccountNoTransfer_KeyUp);
            // 
            // btnClearTransfer
            // 
            this.btnClearTransfer.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearTransfer.Image = ((System.Drawing.Image)(resources.GetObject("btnClearTransfer.Image")));
            this.btnClearTransfer.Location = new System.Drawing.Point(240, 175);
            this.btnClearTransfer.Name = "btnClearTransfer";
            this.btnClearTransfer.Size = new System.Drawing.Size(90, 40);
            this.btnClearTransfer.TabIndex = 12;
            this.btnClearTransfer.Text = "Clear";
            this.btnClearTransfer.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnClearTransfer.UseVisualStyleBackColor = true;
            this.btnClearTransfer.Click += new System.EventHandler(this.btnClearTransfer_Click);
            // 
            // btnSearchTransfer
            // 
            this.btnSearchTransfer.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearchTransfer.Image = ((System.Drawing.Image)(resources.GetObject("btnSearchTransfer.Image")));
            this.btnSearchTransfer.Location = new System.Drawing.Point(135, 175);
            this.btnSearchTransfer.Name = "btnSearchTransfer";
            this.btnSearchTransfer.Size = new System.Drawing.Size(90, 40);
            this.btnSearchTransfer.TabIndex = 11;
            this.btnSearchTransfer.Text = "Search";
            this.btnSearchTransfer.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnSearchTransfer.UseVisualStyleBackColor = true;
            this.btnSearchTransfer.Click += new System.EventHandler(this.btnSearchTransfer_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(290, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 18);
            this.label2.TabIndex = 36;
            this.label2.Text = "Baht";
            // 
            // txtBalanceTransfer
            // 
            this.txtBalanceTransfer.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBalanceTransfer.Location = new System.Drawing.Point(135, 95);
            this.txtBalanceTransfer.MaxLength = 200;
            this.txtBalanceTransfer.Name = "txtBalanceTransfer";
            this.txtBalanceTransfer.ReadOnly = true;
            this.txtBalanceTransfer.Size = new System.Drawing.Size(145, 24);
            this.txtBalanceTransfer.TabIndex = 10;
            this.txtBalanceTransfer.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(60, 98);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 18);
            this.label6.TabIndex = 32;
            this.label6.Text = "Balance";
            // 
            // txtCitizenIdTransfer
            // 
            this.txtCitizenIdTransfer.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCitizenIdTransfer.Location = new System.Drawing.Point(135, 60);
            this.txtCitizenIdTransfer.Mask = "0-0000-00000-00-0";
            this.txtCitizenIdTransfer.Name = "txtCitizenIdTransfer";
            this.txtCitizenIdTransfer.Size = new System.Drawing.Size(195, 24);
            this.txtCitizenIdTransfer.TabIndex = 9;
            this.txtCitizenIdTransfer.Enter += new System.EventHandler(this.txtCitizenIdTransfer_Enter);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(15, 63);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(68, 18);
            this.label16.TabIndex = 15;
            this.label16.Text = "Citizen Id";
            // 
            // txtAccountNoTransfer
            // 
            this.txtAccountNoTransfer.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAccountNoTransfer.Location = new System.Drawing.Point(135, 25);
            this.txtAccountNoTransfer.MaxLength = 30;
            this.txtAccountNoTransfer.Name = "txtAccountNoTransfer";
            this.txtAccountNoTransfer.Size = new System.Drawing.Size(195, 24);
            this.txtAccountNoTransfer.TabIndex = 8;
            this.txtAccountNoTransfer.Enter += new System.EventHandler(this.txtAccountNoTransfer_Enter);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(15, 28);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(86, 18);
            this.label17.TabIndex = 14;
            this.label17.Text = "Account No";
            // 
            // btnCancel
            // 
            this.btnCancel.Enabled = false;
            this.btnCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnCancel.Image")));
            this.btnCancel.Location = new System.Drawing.Point(888, 635);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(95, 50);
            this.btnCancel.TabIndex = 15;
            this.btnCancel.Text = "Clear";
            this.btnCancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Enabled = false;
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.Location = new System.Drawing.Point(783, 635);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(95, 50);
            this.btnSave.TabIndex = 14;
            this.btnSave.Text = "Save";
            this.btnSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // AccountNo
            // 
            this.AccountNo.DataPropertyName = "AccountNo";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.AccountNo.DefaultCellStyle = dataGridViewCellStyle5;
            this.AccountNo.HeaderText = "           Account No";
            this.AccountNo.Name = "AccountNo";
            this.AccountNo.ReadOnly = true;
            this.AccountNo.Width = 225;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "AccountNo";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridViewTextBoxColumn1.HeaderText = "           Account No";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 225;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(630, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 18);
            this.label1.TabIndex = 38;
            this.label1.Text = "FullName (TH)";
            // 
            // txtShowFullNameTH
            // 
            this.txtShowFullNameTH.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtShowFullNameTH.Location = new System.Drawing.Point(630, 60);
            this.txtShowFullNameTH.MaxLength = 30;
            this.txtShowFullNameTH.Name = "txtShowFullNameTH";
            this.txtShowFullNameTH.ReadOnly = true;
            this.txtShowFullNameTH.Size = new System.Drawing.Size(310, 24);
            this.txtShowFullNameTH.TabIndex = 39;
            this.txtShowFullNameTH.TabStop = false;
            // 
            // txtShowFullNameEN
            // 
            this.txtShowFullNameEN.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtShowFullNameEN.Location = new System.Drawing.Point(630, 135);
            this.txtShowFullNameEN.MaxLength = 30;
            this.txtShowFullNameEN.Name = "txtShowFullNameEN";
            this.txtShowFullNameEN.ReadOnly = true;
            this.txtShowFullNameEN.Size = new System.Drawing.Size(310, 24);
            this.txtShowFullNameEN.TabIndex = 41;
            this.txtShowFullNameEN.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(630, 103);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(106, 18);
            this.label4.TabIndex = 40;
            this.label4.Text = "FullName (EN)";
            // 
            // txtShowCitizenId
            // 
            this.txtShowCitizenId.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtShowCitizenId.Location = new System.Drawing.Point(745, 180);
            this.txtShowCitizenId.Mask = "0-0000-00000-00-0";
            this.txtShowCitizenId.Name = "txtShowCitizenId";
            this.txtShowCitizenId.ReadOnly = true;
            this.txtShowCitizenId.Size = new System.Drawing.Size(195, 24);
            this.txtShowCitizenId.TabIndex = 42;
            this.txtShowCitizenId.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(630, 183);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 18);
            this.label5.TabIndex = 43;
            this.label5.Text = "Citizen Id";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(630, 183);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(68, 18);
            this.label9.TabIndex = 49;
            this.label9.Text = "Citizen Id";
            // 
            // txtShowCitizenIdTransfer
            // 
            this.txtShowCitizenIdTransfer.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtShowCitizenIdTransfer.Location = new System.Drawing.Point(745, 180);
            this.txtShowCitizenIdTransfer.Mask = "0-0000-00000-00-0";
            this.txtShowCitizenIdTransfer.Name = "txtShowCitizenIdTransfer";
            this.txtShowCitizenIdTransfer.ReadOnly = true;
            this.txtShowCitizenIdTransfer.Size = new System.Drawing.Size(195, 24);
            this.txtShowCitizenIdTransfer.TabIndex = 48;
            this.txtShowCitizenIdTransfer.TabStop = false;
            // 
            // txtShowFullNameENTransfer
            // 
            this.txtShowFullNameENTransfer.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtShowFullNameENTransfer.Location = new System.Drawing.Point(630, 135);
            this.txtShowFullNameENTransfer.MaxLength = 30;
            this.txtShowFullNameENTransfer.Name = "txtShowFullNameENTransfer";
            this.txtShowFullNameENTransfer.ReadOnly = true;
            this.txtShowFullNameENTransfer.Size = new System.Drawing.Size(310, 24);
            this.txtShowFullNameENTransfer.TabIndex = 47;
            this.txtShowFullNameENTransfer.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(630, 103);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(106, 18);
            this.label10.TabIndex = 46;
            this.label10.Text = "FullName (EN)";
            // 
            // txtShowFullNameTHTransfer
            // 
            this.txtShowFullNameTHTransfer.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtShowFullNameTHTransfer.Location = new System.Drawing.Point(630, 60);
            this.txtShowFullNameTHTransfer.MaxLength = 30;
            this.txtShowFullNameTHTransfer.Name = "txtShowFullNameTHTransfer";
            this.txtShowFullNameTHTransfer.ReadOnly = true;
            this.txtShowFullNameTHTransfer.Size = new System.Drawing.Size(310, 24);
            this.txtShowFullNameTHTransfer.TabIndex = 45;
            this.txtShowFullNameTHTransfer.TabStop = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(630, 28);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(105, 18);
            this.label14.TabIndex = 44;
            this.label14.Text = "FullName (TH)";
            // 
            // ucFinancialBusiness
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.toolStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ucFinancialBusiness";
            this.Size = new System.Drawing.Size(1008, 705);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvShowAccountNo)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvShowAccountNoTransfer)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButtonExit;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtAccountNo;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.MaskedTextBox txtCitizenId;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cboTypeOfFinancial;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtBalance;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtAvailable;
        private System.Windows.Forms.Label lblAvailable;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnClearTransfer;
        private System.Windows.Forms.Button btnSearchTransfer;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtBalanceTransfer;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.MaskedTextBox txtCitizenIdTransfer;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtAccountNoTransfer;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.DataGridView DgvShowAccountNo;
        private System.Windows.Forms.DataGridView DgvShowAccountNoTransfer;
        private System.Windows.Forms.DataGridViewTextBoxColumn AccountNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtShowFullNameTH;
        private System.Windows.Forms.TextBox txtShowFullNameEN;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.MaskedTextBox txtShowCitizenId;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.MaskedTextBox txtShowCitizenIdTransfer;
        private System.Windows.Forms.TextBox txtShowFullNameENTransfer;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtShowFullNameTHTransfer;
        private System.Windows.Forms.Label label14;
    }
}
