﻿using Bank.Lib.Business;
using System;
using System.Web.Http;

namespace BankService.Controllers
{
    public class BaseController : ApiController
    {
        public string GetProgramName
        {
            get
            {
                return "BankService";
            }
        }

        public string GetGuid
        {
            get
            {
                return Guid.NewGuid().ToString();
            }
        }

        public string GetClientIp
        {
            get
            {
                return System.Web.HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
            }
        }

        public string GetHostIp
        {
            get
            {
                return DoBusiness.GetHostIp;
            }
        }
    }
}