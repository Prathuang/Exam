﻿using Bank.Lib.Business;
using Bank.Lib.Data;
using System.Web.Http;

namespace BankService.Controllers
{
    public class MasterController : BaseController
    {
        [HttpPost]
        [System.Web.Http.Route("api/Master/GetAllMaster")]
        public AllMaster GetAllMaster()
        {
            MasterBusiness bs = new MasterBusiness(GetProgramName, GetGuid, GetClientIp, GetHostIp);
            return bs.GetAllMaster();
        }

        [HttpPost]
        [System.Web.Http.Route("api/Master/GetBanksList")]
        public BanksList GetBanksList()
        {
            MasterBusiness bs = new MasterBusiness(GetProgramName, GetGuid, GetClientIp, GetHostIp);
            return bs.GetBanksList();
        }

        [HttpPost]
        [System.Web.Http.Route("api/Master/GetBranchList")]
        public BranchList GetBranchList()
        {
            MasterBusiness bs = new MasterBusiness(GetProgramName, GetGuid, GetClientIp, GetHostIp);
            return bs.GetBranchList();
        }

        [HttpPost]
        [System.Web.Http.Route("api/Master/GetChannelList")]
        public ChannelList GetChannelList()
        {
            MasterBusiness bs = new MasterBusiness(GetProgramName, GetGuid, GetClientIp, GetHostIp);
            return bs.GetChannelList();
        }

        [HttpPost]
        [System.Web.Http.Route("api/Master/GetSubDistrictList")]
        public SubDistrictList GetSubDistrictList()
        {
            MasterBusiness bs = new MasterBusiness(GetProgramName, GetGuid, GetClientIp, GetHostIp);
            return bs.GetSubDistrictList();
        }

        [HttpPost]
        [System.Web.Http.Route("api/Master/GetDistrictList")]
        public DistrictList GetDistrictList()
        {
            MasterBusiness bs = new MasterBusiness(GetProgramName, GetGuid, GetClientIp, GetHostIp);
            return bs.GetDistrictList();
        }

        [HttpPost]
        [System.Web.Http.Route("api/Master/GetProvinceList")]
        public ProvinceList GetProvinceList()
        {
            MasterBusiness bs = new MasterBusiness(GetProgramName, GetGuid, GetClientIp, GetHostIp);
            return bs.GetProvinceList();
        }

        [HttpPost]
        [System.Web.Http.Route("api/Master/GetOccupationList")]
        public OccupationList GetOccupationList()
        {
            MasterBusiness bs = new MasterBusiness(GetProgramName, GetGuid, GetClientIp, GetHostIp);
            return bs.GetOccupationList();
        }

        [HttpPost]
        [System.Web.Http.Route("api/Master/GetTitleList")]
        public TitleList GetTitleList()
        {
            MasterBusiness bs = new MasterBusiness(GetProgramName, GetGuid, GetClientIp, GetHostIp);
            return bs.GetTitleList();
        }

        [HttpPost]
        [System.Web.Http.Route("api/Master/GetTypeFinancialList")]
        public TypeFinancialList GetTypeFinancialList()
        {
            MasterBusiness bs = new MasterBusiness(GetProgramName, GetGuid, GetClientIp, GetHostIp);
            return bs.GetTypeFinancialList();
        }

    }
}