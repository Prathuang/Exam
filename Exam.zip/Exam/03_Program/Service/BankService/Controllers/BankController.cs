﻿using Bank.Lib.Business;
using Bank.Lib.Data;
using System.Web.Http;

namespace BankService.Controllers
{
    public class BankController : BaseController
    {
        [HttpPost]
        [System.Web.Http.Route("api/Bank/GetIBANNumber")]
        public string GetIBANNumber()
        {
            BanksBusiness bs = new BanksBusiness(GetProgramName, GetGuid, GetClientIp, GetHostIp);
            return bs.GetIBANNumber();
        }

        [HttpPost]
        [System.Web.Http.Route("api/Bank/InsertFinancialTransaction")]
        public ResultResponse InsertFinancialTransaction([FromBody]FinancialTransaction request)
        {
            BanksBusiness bs = new BanksBusiness(GetProgramName, GetGuid, GetClientIp, GetHostIp);
            return bs.InsertFinancialTransaction(request);
        }

        [HttpPost]
        [System.Web.Http.Route("api/Bank/GetBalanceData")]
        public BalanceDataList GetBalanceData([FromBody]BalanceData request)
        {
            BanksBusiness bs = new BanksBusiness(GetProgramName, GetGuid, GetClientIp, GetHostIp);
            return bs.GetBalanceData(request);
        }
    }
}