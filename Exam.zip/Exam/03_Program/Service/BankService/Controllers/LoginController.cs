﻿using Bank.Lib.Business;
using Bank.Lib.Data;
using System.Web.Http;

namespace BankService.Controllers
{
    public class LoginController : BaseController
    {
        [HttpPost]
        [System.Web.Http.Route("api/Login/CheckUserLogin")]
        public ManageUserList CheckUserLogin([FromBody]ManageUser request)
        {
            LoginBusiness bs = new LoginBusiness(GetProgramName, GetGuid, GetClientIp, GetHostIp);
            return bs.CheckUserLogin(request);
        }
    }
}