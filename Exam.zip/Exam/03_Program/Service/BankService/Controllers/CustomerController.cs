﻿using Bank.Lib.Business;
using Bank.Lib.Data;
using System.Web.Http;

namespace BankService.Controllers
{
    public class CustomerController : BaseController
    {
        [HttpPost]
        [System.Web.Http.Route("api/Customer/InsertCustomer")]
        public ResultResponse InsertCustomer([FromBody]Customer request)
        {
            CustomerBusiness bs = new CustomerBusiness(GetProgramName, GetGuid, GetClientIp, GetHostIp);
            return bs.InsertCustomer(request);
        }

        [HttpPost]
        [System.Web.Http.Route("api/Customer/CheckCustomer")]
        public CustomerList CheckCustomer([FromBody]CustomerForSearch request)
        {
            CustomerBusiness bs = new CustomerBusiness(GetProgramName, GetGuid, GetClientIp, GetHostIp);
            return bs.CheckCustomer(request);
        }
    }
}